package com.bistri.api;

import android.app.ActivityManager;
import android.content.Context;
import android.content.pm.ConfigurationInfo;
import android.util.Log;
import android.view.SurfaceHolder;
import android.view.SurfaceView;

import java.lang.reflect.InvocationTargetException;

public class Renderer
{

    // View used for local rendering that Cameras can use for Video Overlay.
    private static SurfaceHolder g_localRenderer;
    private static String TAG = "Renderer";

    /**
     * Create a surface video renderer.
     * 
     * <pre>
     * {@code
     *     // Note used internally
     * }
     * </pre>
     * @return SurfaceView
     */
    public static SurfaceView CreateRenderer()
    {
        return CreateRenderer( false );
    }

    /**
     * Create a surface or openGL video renderer.
     * @param useOpenGLES2 (boolean) True means use openGLES2.
     * 
     * <pre>
     * {@code
     *     // Note used internally
     * }
     * </pre>
     * @return SurfaceView
     */
    public static SurfaceView CreateRenderer( boolean useOpenGLES2 )
    {
        Conference conference = Conference.getInstance();
        if ( useOpenGLES2 == true && hasOpenGLES20( conference.getContext() ) )
        {
            return CreateGLRender( conference );
        }
        else
        {
            return new SurfaceView( conference.getContext() );
        }
    }

    private static GLRenderer CreateGLRender( Conference conference ) {
        String className = GLRenderer.class.getName();

        if ( conference.hasGeneralOption( Conference.GeneralOption.GL_RENDERER ) ) {
            className = conference.getGeneralOption_String( Conference.GeneralOption.GL_RENDERER );
        }

        GLRenderer renderer = null;
        try {
            Class gl_render_class = Class.forName( className );;
            gl_render_class.asSubclass( GLRenderer.class ).getConstructor( Context.class ).newInstance( conference.getContext() );
        } catch (ClassNotFoundException e) {
            Log.e(TAG, "Class " + className + " not found : ");
        } catch (InstantiationException e) {
            Log.e( TAG, "InstantiationException of " + className, e );
        } catch (IllegalAccessException e) {
            Log.e( TAG, "IllegalAccessException in " + className, e );
        } catch (NoSuchMethodException e) {
            Log.e( TAG, "NoSuchMethodException when trying to instantiate " + className, e );
        } catch (InvocationTargetException e) {
            Log.e( TAG, "InvocationTargetException in " + className, e );
        }
        if ( renderer != null ) {
            return renderer;
        }
        // return the default GLRenderer
        return new GLRenderer( conference.getContext() );
    }

    /**
     * Create a video renderer for local stream.
     * @param context (android.content.Context).
     * 
     * <pre>
     * {@code
     *     // Note used internally
     * }
     * </pre>
     * @return SurfaceView
     */
    public static SurfaceView CreateLocalRenderer( Context context )
    {
        SurfaceView localRender = new SurfaceView( context );

        g_localRenderer = localRender.getHolder();
        return localRender;
    }

    /**
     * Get the last local renderer created.
     * 
     * <pre>
     * {@code
     *     // Usage
     *     SurfaceHolder holder = Renderer.GetLocalRenderer();
     * }
     * </pre>
     * @return SurfaceHolder
     */
    public static SurfaceHolder GetLocalRenderer()
    {
        return g_localRenderer;
    }

    /**
     * Check if OpenGL ES 2.0 is available on current device.
     * @param context (android.content.Context)
     * 
     * <pre>
     * {@code
     *     if ( Renderer.hasOpenGLES20() ) {
     *         // Something
     *     }
     * }
     * </pre>
     * @return True if available.
     */
    public static boolean hasOpenGLES20( Context context )
    {
        ActivityManager am = (ActivityManager) context.getSystemService( Context.ACTIVITY_SERVICE );
        ConfigurationInfo info = am.getDeviceConfigurationInfo();

        return info.reqGlEsVersion >= 0x20000;
    }
}
