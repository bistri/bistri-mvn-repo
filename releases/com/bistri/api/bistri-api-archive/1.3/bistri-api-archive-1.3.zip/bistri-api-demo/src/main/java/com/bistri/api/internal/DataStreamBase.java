package com.bistri.api.internal;

import android.util.Log;

import com.bistri.api.DataStream;

import java.nio.ByteBuffer;

/**
 * Soon
 */
public class DataStreamBase
    implements DataStream
{
    public enum Event
    {
        create, open, close, error, message, message_binary;
    }
    private static final String TAG = "DataStreamBase";

    Handler handler;
    private String pid;
    private String label;
    private Status status;

    private native void nativeDataChannelSend( String pid, String label, ByteBuffer message, boolean binary );
    private native void nativeDataChannelClose( String pid, String label );

    public DataStreamBase( String pid, String label )
    {
        this.label = label;
        this.pid = pid;
        this.status = Status.PENDING;
    }

    public void setHandler( Handler handler )
    {
        this.handler = handler;
    }

    public void onEvent( Event event, Object value ) {
        if ( handler == null ) return;
        switch( event ) {
            case open:
                status = Status.OPEN;
                handler.onOpen( this );
                break;
            case message:
            case message_binary:
                Log.w( TAG, "receive message" );
                handler.onMessage( this, (ByteBuffer)value, event==Event.message_binary );
                break;
            case close:
                status = Status.CLOSED;
                handler.onClose( this );
                break;
            case error:
                handler.onError( this, (String)value );
                break;
        }
    }

    @Override
    public void send(ByteBuffer message, boolean binary) {
        // Need a direct byte buffer
        if ( message.isDirect() ) {
            nativeDataChannelSend( pid, label, message, binary );
        } else {
            ByteBuffer bb = ByteBuffer.allocateDirect( message.capacity() );
            bb.put( message );
            nativeDataChannelSend( pid, label, bb, binary );
        }
    }

    @Override
    public void send(String message) {
        // Need a direct byte buffer
        ByteBuffer bb = ByteBuffer.allocateDirect( message.length() );
        bb.put( message.getBytes() );
        nativeDataChannelSend( pid, label, bb, false );
    }

    @Override
    public String getLabel() {
        return this.label;
    }

    public void setStatus( Status status ) {
        this.status = status;
    }

    @Override
    public Status getStatus() {
        return status;
    }

    @Override
    public void close() {
        this.status = Status.CLOSED;

        nativeDataChannelClose( pid, label );
    }
}
