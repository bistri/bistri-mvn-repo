package com.bistri.api.internal;

import android.hardware.Camera;

public class FrameRateConstrictor implements Camera.PreviewCallback {

    private long lastFrameMs;
    private int frameInterval;
    private Camera.PreviewCallback realCB;


    public FrameRateConstrictor() {
        setFrameRate( 60 );
    }

    public void setCallback( Camera.PreviewCallback cb ) {
        realCB = cb;
    }
    public void setFrameRate( int fps ) {
        frameInterval = 1000/fps;
    }

    @Override
    public void onPreviewFrame(byte[] data, Camera camera) {
        long currentFrameMs = System.currentTimeMillis();
        long diff = currentFrameMs-lastFrameMs;

        if ( diff < frameInterval ) {
            camera.addCallbackBuffer( data );
        } else {
            lastFrameMs = currentFrameMs;
            realCB.onPreviewFrame( data, camera );
        }
    }
}
