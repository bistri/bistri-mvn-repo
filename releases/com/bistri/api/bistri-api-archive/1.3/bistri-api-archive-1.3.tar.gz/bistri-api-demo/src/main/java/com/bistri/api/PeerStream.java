package com.bistri.api;

import java.util.Map;

public interface PeerStream
{

    /**
     * PeerStream handler.
     */
    public interface Handler
    {
        /**
         * Called when media stream is available.
         *
         * @param peer_id (String) The peer identifier
         * @param mediaStream The media stream
         */
        void onMediaStream( String peer_id, MediaStream mediaStream );
        /**
         * Called when a DataStream is available.
         *
         * @param peer_id (String) The peer identifier
         * @param dataStream The data stream
         */
        void onDataStream( String peer_id, DataStream dataStream );
    }

    /**
     * Get peer identifier of this stream
     * 
     * <pre>
     * {@code
     *     // Usage
     *     String peerId = peerStream.getId();
     * }
     * </pre>
     *
     * @return String.
     */
    public String getId();


    /**
     * Test if the peer stream is local or not.
     * 
     * <pre>
     * {@code
     *     // Usage
     *     if ( peerStream.isLocal() == true ) { ... }
     * }
     * </pre>
     *
     * @return True if the peer stream is the local one.
     */
    public boolean isLocal();

    /**
     * Test if peer stream contains a media stream
     * 
     * <pre>
     * {@code
     *     // Usage
     *     if ( peerStream.hasMedia() == true ) { ... }
     * }
     * </pre>
     *
     * @return True if peer stream contains a media stream, false otherwise.
     */
    public boolean hasMedia();

    /**
     * Get the media stream, if any.
     * 
     * <pre>
     * {@code
     *     // Usage
     *     MediaStream mediaStream = peerStream.getMedia();
     * }
     * </pre>
     *
     * @return MediaStream.
     */
    public MediaStream getMedia();

    /**
     * Open a DataChannel with the current peer.
     *
     * <pre>
     * {@code
     *     // Usage
     *     DataStream dataStream = peerStream.openDataChannel( "myLabel" );
     * }
     * </pre>
     *
     * @param label (String) Label of the DataChannel
     * @return DataStream.
     */
    public DataStream openDataChannel(String label);

    /**
     * Get a DataChannel of the current peer.
     *
     * <pre>
     * {@code
     *     // Usage
     *     DataStream dataStream = peerStream.getDataChannel( "myLabel" );
     * }
     * </pre>
     *
     * @param label (String) Label of the DataChannel
     * @return DataStream.
     */
    public DataStream getDataChannel( String label );

    /**
     * Get all DataChannel of the current peer.
     * 
     * <pre>
     * {@code
     *     // Usage
     *     Map<String, DataStream> channels = peerStream.getDataChannels();
     * }
     * </pre>
     *
     * @return DataStream.
     */
    public Map<String, DataStream> getDataChannels();

    /**
     * Set an handle for this peer stream
     * 
     * <pre>
     * {@code
     *     // Usage
     *     peerStream.setHandler( handler );
     * }
     * </pre>
     *
     * @param handler peer stream handler
     */
    public void setHandler( Handler handler );
}
