package com.bistri.api.internal;

public interface Constants
{
    static final String API_VERSION = "1.3.0";
}
