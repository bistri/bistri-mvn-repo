package com.bistri.api;

import android.content.Context;
import android.opengl.GLSurfaceView;
import android.util.Log;

import javax.microedition.khronos.egl.EGL10;
import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.egl.EGLContext;
import javax.microedition.khronos.egl.EGLDisplay;
import javax.microedition.khronos.opengles.GL10;
import java.util.concurrent.locks.ReentrantLock;

public class GLRenderer
        extends GLSurfaceView
        implements GLSurfaceView.Renderer
{
    private static String TAG = "GLRenderer";

    protected boolean surfaceCreated = false;
    protected int surfaceWidth = 0;
    protected int surfaceHeight = 0;

    protected boolean openGLCreated = false;

    protected ReentrantLock nativeLock = new ReentrantLock();
    protected long nativeReference = 0;   // Address of Native renderer object
    protected native int CreateOpenGLNative( long nativeObject, int width, int height );
    protected native void DrawNative( long nativeObject );

    public GLRenderer(Context context) {
        super( context );
        initialize();
    }

    protected void initialize()
    {
        setEGLContextFactory( new ContextFactory() );

        setEGLConfigChooser(new ConfigChooser( 5, 6, 5, 0, 0, 0 ) );

        // Set the renderer responsible for frame rendering
        this.setRenderer( this );
        this.setRenderMode( GLSurfaceView.RENDERMODE_WHEN_DIRTY );
    }

    private static class ContextFactory
            implements GLSurfaceView.EGLContextFactory
    {
        private static int EGL_CONTEXT_CLIENT_VERSION = 0x3098;

        public EGLContext createContext( EGL10 egl, EGLDisplay display, EGLConfig eglConfig ) {
            Log.w( TAG, "creating OpenGL ES 2.0 context" );
            checkEglError( "Before eglCreateContext", egl );
            int[] attrib_list = { EGL_CONTEXT_CLIENT_VERSION, 2, EGL10.EGL_NONE };
            EGLContext context = egl.eglCreateContext( display, eglConfig, EGL10.EGL_NO_CONTEXT, attrib_list );
            checkEglError( "After eglCreateContext", egl );
            return context;
        }

        private static void checkEglError( String prompt, EGL10 egl ) {
            int error;
            while ( ( error = egl.eglGetError() ) != EGL10.EGL_SUCCESS ) {
                Log.e( TAG, String.format( "%s: EGL error: 0x%x", prompt, error ) );
            }
        }

        public void destroyContext( EGL10 egl, EGLDisplay display, EGLContext context ) {
            egl.eglDestroyContext( display, context );
        }
    }


    private static class ConfigChooser
            implements GLSurfaceView.EGLConfigChooser
    {

        public ConfigChooser( int r, int g, int b, int a, int depth, int stencil ) {
            redSize = r;
            greenSize = g;
            blueSize = b;
            alphaSize = a;
            depthSize = depth;
            stencilSize = stencil;
        }
        private static int EGL_OPENGL_ES2_BIT = 4;

        private static int[] s_configAttribs2 = {
            EGL10.EGL_RED_SIZE, 4,
            EGL10.EGL_GREEN_SIZE, 4,
            EGL10.EGL_BLUE_SIZE, 4,
            EGL10.EGL_RENDERABLE_TYPE, EGL_OPENGL_ES2_BIT,
            EGL10.EGL_NONE
        };

        // Subclasses can adjust these values:
        protected int redSize;
        protected int greenSize;
        protected int blueSize;
        protected int alphaSize;
        protected int depthSize;
        protected int stencilSize;
        private int[] mValue = new int[1];

        public EGLConfig chooseConfig( EGL10 egl, EGLDisplay display ) {

            // Get the number of minimally matching EGL configurations
            int[] num_config = new int[1];
            egl.eglChooseConfig( display, s_configAttribs2, null, 0, num_config );

            int numConfigs = num_config[0];

            if ( numConfigs <= 0 )
            {
                throw new IllegalArgumentException( "No configs match configSpec" );
            }

            // Allocate then read the array of minimally matching EGL configs
            EGLConfig[] configs = new EGLConfig[numConfigs];
            egl.eglChooseConfig( display, s_configAttribs2, configs, numConfigs, num_config );

            // Now return the "best" one
            return chooseConfig( egl, display, configs );
        }

        public EGLConfig chooseConfig( EGL10 egl, EGLDisplay display, EGLConfig[] configs )  {
            for ( EGLConfig config : configs ) {
                int d = findConfigAttrib( egl, display, config, EGL10.EGL_DEPTH_SIZE, 0 );
                int s = findConfigAttrib( egl, display, config, EGL10.EGL_STENCIL_SIZE, 0 );

                // We need at least depthSize and stencilSize bits
                if ( d < depthSize || s < stencilSize) {
                    continue;
                }

                // We want an *exact* match for red/green/blue/alpha
                int r = findConfigAttrib( egl, display, config, EGL10.EGL_RED_SIZE, 0 );
                int g = findConfigAttrib( egl, display, config, EGL10.EGL_GREEN_SIZE, 0 );
                int b = findConfigAttrib( egl, display, config, EGL10.EGL_BLUE_SIZE, 0 );
                int a = findConfigAttrib( egl, display, config, EGL10.EGL_ALPHA_SIZE, 0 );

                if ( r == redSize && g == greenSize && b == blueSize && a == alphaSize) {
                    return config;
                }
            }
            return null;
        }

        private int findConfigAttrib( EGL10 egl, EGLDisplay display, EGLConfig config, int attribute, int defaultValue ) {

            if ( egl.eglGetConfigAttrib( display, config, attribute, mValue ) ) {
                return mValue[0];
            }
            return defaultValue;
        }
    }

    protected boolean CreateOpenGL() {
        boolean ret = false;
        nativeLock.lock();
        if ( nativeReference != 0 ) {
            if ( CreateOpenGLNative(nativeReference, surfaceWidth, surfaceHeight ) == 0 ) {
                openGLCreated = ret = true;
            }
        }
        nativeLock.unlock();
        return ret;
    }

    public void onDrawFrame( GL10 gl )
    {
        nativeLock.lock();

        if ( nativeReference == 0 || !surfaceCreated ) {
            nativeLock.unlock();
            return;
        }

        if ( !openGLCreated ) {
            if ( !CreateOpenGL() ) {
                nativeLock.unlock();
                return;
            }
        }

        DrawNative(nativeReference); // Draw the new frame

        nativeLock.unlock();
    }

    @Override
    public void onSurfaceCreated(GL10 gl10, EGLConfig eglConfig) {

    }

    @Override
    public void onSurfaceChanged( GL10 gl, int width, int height )
    {
        surfaceCreated = true;
        surfaceWidth = width;
        surfaceHeight = height;

        CreateOpenGL();
    }

    @SuppressWarnings( "unused" ) // Called from native library
    public static boolean IsGLRenderer( Object renderWindow )
    {
        return GLRenderer.class.isInstance( renderWindow );
    }

    @SuppressWarnings( "unused" ) // Called from native library
    public void RegisterNativeObject( long nativeObject )
    {
        nativeLock.lock();
        this.nativeReference = nativeObject;
        nativeLock.unlock();
    }

    @SuppressWarnings( "unused" ) // Called from native library
    public void DeRegisterNativeObject()
    {
        nativeLock.lock();
        openGLCreated = false;
        this.nativeReference = 0;
        nativeLock.unlock();
    }

    @SuppressWarnings( "unused" ) // Called from native library
    public void ReDraw()
    {
        if ( surfaceCreated )
        {
            // Request the renderer to redraw using the render thread context.
            this.requestRender();
        }
    }

}
