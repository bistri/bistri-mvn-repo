package com.bistri.api.internal;

import android.util.Log;
import android.view.SurfaceView;
import android.widget.Toast;

import com.bistri.api.Conference;
import com.bistri.api.MediaStream;
import com.bistri.api.Renderer;

import org.webrtc.videoengine.VideoCaptureAndroid;

public class MediaStreamBase
    implements MediaStream, VideoCaptureAndroid.EventHandler
{
    public static final int TYPE_AUDIO = 0;
    public static final int TYPE_VIDEO = 1;

    Handler handler;

    private int stream_id = -1;
    private SurfaceView render = null;

    private String peer_id;

    private float video_ratio = 4.0f / 3.0f;

    private boolean video = false;

    private boolean audio_muted = false;
    private boolean video_muted = false;

    private native void nativeMute( int streamId, int type, boolean mute );
    private native boolean nativeHasVideo( int streamId );
    private native boolean nativeHasAudio( int streamId );
    private native void nativeSetView( int streamId, SurfaceView view );

    public MediaStreamBase( int streamId, String pid ) {
        stream_id = streamId;
        peer_id = pid;

        if ( isLocal() ) {
            video_ratio = VideoCaptureAndroid.getLocalPreviewRatio();
        }
    }

    public void setHandler( Handler handler )
    {
        this.handler = handler;
    }

    private void addVideoRender() {
        if ( peer_id.equals( "local" ) ) {
            render = Conference.getInstance().getLocalRender();

            VideoCaptureAndroid.setLocalPreview(render, this);
        } else {
            render = Renderer.CreateRenderer(true);
            nativeSetView( stream_id, render );
        }
    }

    public SurfaceView getRender() {
        if ( render == null )
            addVideoRender();
        return render;
    }

    @Override
    public boolean hasVideo() {
        return nativeHasVideo( stream_id );
    }

    public boolean hasAudio() {
        return nativeHasAudio( stream_id );
    }

    public void setVideoRatio( float ratio ) {
        video_ratio = ratio;
        if ( handler != null ) {
            handler.onVideoRatioChange( peer_id, (MediaStream) this, ratio );
        }
    }

    private boolean isLocal()
    {
        return peer_id.equals( "local" );
    }

    public float getVideoRatio()
    {
        return video_ratio;
    }

    @Override
    public void muteAudio(boolean mute) {
        nativeMute( stream_id, TYPE_AUDIO, mute );
        audio_muted = mute;
    }

    @Override
    public void muteVideo(boolean mute) {
        nativeMute( stream_id, TYPE_VIDEO, mute );
        video_muted = mute;
    }

    @Override
    public boolean isAudioMute() {
        return audio_muted;
    }

    @Override
    public boolean isVideoMute() {
        return video_muted;
    }

    @Override
    public String getPeerId() {
        return peer_id;
    }

    @Override
    public void onCapturerOrientationChange() {
        setVideoRatio( VideoCaptureAndroid.getLocalPreviewRatio() );
    }
}
