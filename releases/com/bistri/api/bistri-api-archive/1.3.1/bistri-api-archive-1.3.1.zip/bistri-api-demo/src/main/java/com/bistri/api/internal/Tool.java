package com.bistri.api.internal;

import android.util.Log;

/**
 * Created by ahiron on 10/09/2014.
 */
public class Tool {
    private static final String TAG = "Tool";

    public static int fibonacci( int nb ) {
        nb = Math.abs( nb );
        return  ( nb < 2 ) ? nb : ( fibonacci( nb - 1 ) + fibonacci( nb - 2 ) );
    }
}
