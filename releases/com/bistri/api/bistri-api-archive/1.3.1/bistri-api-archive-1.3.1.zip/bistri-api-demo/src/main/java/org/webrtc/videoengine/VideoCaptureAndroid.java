/*
 *  Copyright (c) 2012 The WebRTC project authors. All Rights Reserved.
 *
 *  Use of this source code is governed by a BSD-style license
 *  that can be found in the LICENSE file in the root of the source
 *  tree. An additional intellectual property rights grant can be found
 *  in the file PATENTS.  All contributing project authors may
 *  be found in the AUTHORS file in the root of the source tree.
 */

package org.webrtc.videoengine;

import java.io.IOException;
import java.util.List;
import java.util.concurrent.Exchanger;

import android.annotation.TargetApi;
import android.content.Context;
import android.graphics.ImageFormat;
import android.graphics.SurfaceTexture;
import android.hardware.Camera.PreviewCallback;
import android.hardware.Camera;
import android.opengl.GLES11Ext;
import android.opengl.GLES20;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.util.Log;
import android.view.Surface;
import android.view.SurfaceHolder.Callback;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.WindowManager;

import com.bistri.api.Conference;
import com.bistri.api.internal.FrameRateConstrictor;

import static java.lang.Math.abs;

// Wrapper for android Camera, with support for direct local preview rendering.
// Threading notes: this class is called from ViE C++ code, and from Camera &
// SurfaceHolder Java callbacks.  Since these calls happen on different threads,
// the entry points to this class are all synchronized.  This shouldn't present
// a performance bottleneck because only onPreviewFrame() is called more than
// once (and is called serially on a single thread), so the lock should be
// uncontended.  Note that each of these synchronized methods must check
// |camera| for null to account for having possibly waited for stopCapture() to
// complete.
public class VideoCaptureAndroid implements PreviewCallback, Callback {
  private final static String TAG = "VideoCaptureAndroid";

  private static SurfaceHolder localPreview;
  private int orientation = -1;
  private static int previewOrientation = -1;
  private Camera camera;  // Only non-null while capturing.
  private CameraThread cameraThread;
  private Handler cameraThreadHandler;
  private Context context;
  private int id;
  private Camera.CameraInfo info;
  private final long native_capturer;  // |VideoCaptureAndroid*| in C++.
  private SurfaceTexture dummyCameraSurfaceTexture;
  private int[] cameraGlTextures = null;
  // Arbitrary queue depth.  Higher number means more memory allocated & held,
  // lower number means more sensitivity to processing time in the client (and
  // potentially stalling the capturer if it runs out of buffers to write to).
  private final int numCaptureBuffers = 3;
  private double averageDurationMs;
  private long lastCaptureTimeMs;
  private int frameCount;
  private int width, height, min_mfps, max_mfps;
  private static VideoCaptureAndroid last_instance = null;
  private static EventHandler eventHandler = null;

    // Requests future capturers to send their frames to |localPreview| directly.
  public static void setLocalPreview(SurfaceView localRender, EventHandler handler) {
    VideoCaptureAndroid.localPreview = localRender.getHolder();
    if ( last_instance != null && last_instance.dummyCameraSurfaceTexture != null ) {
        localPreview.addCallback(last_instance);
    }
    eventHandler = handler;
  }

    public interface EventHandler
    {
        void onCapturerOrientationChange();
    }

    public static float getLocalPreviewRatio() {
        float ratio = ( last_instance != null ) ? ((float)last_instance.width/last_instance.height) : (float)1.33;
        return (VideoCaptureAndroid.previewOrientation%180 != 0) ? 1/ratio : ratio;
    }

    public static void setCamera( int cameraId ) {
        if ( last_instance != null ) {
            last_instance.changeCamera( cameraId );
        }
    }

    private void changeCamera(int cameraId) {
        if ( cameraThreadHandler == null || cameraThread == null ) {
        Log.d( TAG, "cameraThreadHandler or cameraThread is null" );
                return;
        }

        if ( cameraId == id ) {
            Log.d( TAG, "Camera is already set" );
            return;
        }

        final int newId = cameraId;
        cameraThreadHandler.post(new Runnable() {
            @Override
            public void run() {
                changeCameraOnCameraThread(newId);
            }
        });
    }

  public VideoCaptureAndroid(int id, long native_capturer) {
    last_instance = this;
    this.id = id;
    this.native_capturer = native_capturer;
    this.context = GetContext();
    this.info = new Camera.CameraInfo();
    Camera.getCameraInfo(id, info);
  }

  // Return the global application context.
  private static native Context GetContext();

  private class CameraThread extends Thread {
    private Exchanger<Handler> handlerExchanger;
    public CameraThread(Exchanger<Handler> handlerExchanger) {
      this.handlerExchanger = handlerExchanger;
    }

    @Override public void run() {
      Looper.prepare();
      exchange(handlerExchanger, new Handler());
      Looper.loop();
    }
  }

  // Called by native code.  Returns true if capturer is started.
  //
  // Note that this actually opens the camera, and Camera callbacks run on the
  // thread that calls open(), so this is done on the CameraThread.  Since ViE
  // API needs a synchronous success return value we wait for the result.
  private synchronized boolean startCapture(
      final int width, final int height,
      final int min_mfps, final int max_mfps) {
    Log.d(TAG, "startCapture: " + width + "x" + height + "@" +
        min_mfps + ":" + max_mfps);
    if (cameraThread != null || cameraThreadHandler != null) {
      throw new RuntimeException("Camera thread already started!");
    }

    updateOrientation();

    Exchanger<Handler> handlerExchanger = new Exchanger<Handler>();
    cameraThread = new CameraThread(handlerExchanger);
    cameraThread.start();
    cameraThreadHandler = exchange(handlerExchanger, null);

    final Exchanger<Boolean> result = new Exchanger<Boolean>();
    cameraThreadHandler.post(new Runnable() {
        @Override public void run() {
          startCaptureOnCameraThread(width, height, min_mfps, max_mfps, result);
        }
      });
    boolean startResult = exchange(result, false); // |false| is a dummy value.
    return startResult;
  }

  private void startCaptureOnCameraThread( int width, int height, int min_mfps, int max_mfps, Exchanger<Boolean> result) {
    this.width = width;
    this.height = height;
    this.min_mfps = min_mfps;
    this.max_mfps = max_mfps;

    startCaptureOnCameraThread(result);
  }

  @TargetApi(Build.VERSION_CODES.ICE_CREAM_SANDWICH_MR1)
  private void setVideoStabilization(Camera.Parameters parameters) {
      Log.d(TAG, "isVideoStabilizationSupported: " + parameters.isVideoStabilizationSupported());
      if (parameters.isVideoStabilizationSupported()) {
          parameters.setVideoStabilization(true);
      }
  }

  private void startCaptureOnCameraThread(Exchanger<Boolean> result) {
    Throwable error;
    try {
      camera = Camera.open(id);
      Camera.getCameraInfo(id, info);

      if (localPreview != null) {
        localPreview.addCallback(this);
        if (localPreview.getSurface() != null &&
            localPreview.getSurface().isValid()) {
          camera.setPreviewDisplay(localPreview);
        }
      } else {
        // No local renderer (we only care about onPreviewFrame() buffers, not a
        // directly-displayed UI element).  Camera won't capture without
        // setPreview{Texture,Display}, so we create a SurfaceTexture and hand
        // it over to Camera, but never listen for frame-ready callbacks,
        // and never call updateTexImage on it.
        try {
          cameraGlTextures = new int[1];
          // Generate one texture pointer and bind it as an external texture.
          GLES20.glGenTextures(1, cameraGlTextures, 0);
          GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES,
              cameraGlTextures[0]);
          GLES20.glTexParameterf(GLES11Ext.GL_TEXTURE_EXTERNAL_OES,
              GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR);
          GLES20.glTexParameterf(GLES11Ext.GL_TEXTURE_EXTERNAL_OES,
              GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR);
          GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES,
              GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE);
          GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES,
              GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE);

          dummyCameraSurfaceTexture = new SurfaceTexture(cameraGlTextures[0]);
          dummyCameraSurfaceTexture.setOnFrameAvailableListener(null);
          camera.setPreviewTexture(dummyCameraSurfaceTexture);
        } catch (IOException e) {
          throw new RuntimeException(e);
        }
      }

      Camera.Parameters parameters = camera.getParameters();

      if (Build.VERSION.SDK_INT >= 15) {
          if (parameters.isVideoStabilizationSupported()) {
              parameters.setVideoStabilization(true);
          }
      }

      // Autofocus management
      List<String> supportedFocusModes = camera.getParameters().getSupportedFocusModes();
      if ( supportedFocusModes.contains(Camera.Parameters.FOCUS_MODE_CONTINUOUS_VIDEO ) ) {
        parameters.setFocusMode(Camera.Parameters.FOCUS_MODE_CONTINUOUS_VIDEO);
      } else if ( supportedFocusModes.contains(Camera.Parameters.FOCUS_MODE_AUTO ) ) {
        parameters.setFocusMode(Camera.Parameters.FOCUS_MODE_AUTO);
      }

      List<Camera.Size> sizes = parameters.getSupportedPictureSizes();
      if (sizes != null && sizes.size() != 0) {
          parameters.setPictureSize(sizes.get(0).width, sizes.get(0).height);
          Camera.Size choosenSize = null;
          for(Camera.Size s : sizes) {
              if( ( s.width == width ) && ( s.height == height ) ) {
                  choosenSize = s;
                  break;
              } else if ( choosenSize == null ) {
                  choosenSize = s;
              } else {
                  int curSize = s.width*s.height;
                  float curRatio = ((float)s.width)/s.height;
                  int bestSize = choosenSize.width*choosenSize.height;
                  float bestRatio = ((float)choosenSize.width)/choosenSize.height;
                  int wantedSize = width*height;
                  float wantedRatio = ((float)width)/height;

                  if ( abs(wantedSize-curSize) > abs(wantedSize-bestSize) ) {
                    continue;
                  }
                  if ( abs(wantedRatio-curRatio) > abs(wantedRatio-bestRatio) ) {
                    continue;
                  }

                  // This size is more close to the requested
                  choosenSize = s;
              }
          }

          parameters.setPictureSize(choosenSize.width, choosenSize.height);
      }

      parameters.setPreviewSize(width, height);
      parameters.setPreviewFpsRange(min_mfps, max_mfps);
      int format = ImageFormat.NV21;
      parameters.setPreviewFormat(format);
      camera.setParameters(parameters);
      int bufSize = width * height * ImageFormat.getBitsPerPixel(format) / 8;
      for (int i = 0; i < numCaptureBuffers; i++) {
        camera.addCallbackBuffer(new byte[bufSize]);
      }

        Conference conf = Conference.getInstance();
        if ( conf.hasVideoOption(Conference.VideoOption.MAX_FRAME_RATE) ) {
            FrameRateConstrictor frc = new FrameRateConstrictor();
            frc.setCallback(this);
            frc.setFrameRate(conf.getVideoOption_int(Conference.VideoOption.MAX_FRAME_RATE));
            camera.setPreviewCallbackWithBuffer(frc);
        } else {
            camera.setPreviewCallbackWithBuffer(this);
        }

      frameCount = 0;
      averageDurationMs = 1000 / max_mfps;

      camera.setDisplayOrientation( previewOrientation );
      camera.startPreview();

      if ( result != null )
        exchange(result, true);
      return;
    } catch (IOException e) {
      error = e;
    } catch (RuntimeException e) {
      error = e;
    }
    Log.e(TAG, "startCapture failed", error);
    if (camera != null) {
      stopCaptureOnCameraThread(true, null);
    }
    if ( result != null )
      exchange(result, false);
  }

  // Called by native code.  Returns true when camera is known to be stopped.
  private synchronized boolean stopCapture() {
    final Exchanger<Boolean> result = new Exchanger<Boolean>();
    cameraThreadHandler.post(new Runnable() {
        @Override public void run() {
          stopCaptureOnCameraThread(true, result);
        }
      });
    boolean status = exchange(result, false);  // |false| is a dummy value here.
    try {
      cameraThread.join();
    } catch (InterruptedException e) {
      throw new RuntimeException(e);
    }
    cameraThreadHandler = null;
    cameraThread = null;
    return status;
  }

  private void changeCameraOnCameraThread( int cameraId ) {
      stopCaptureOnCameraThread(false, null);
      id = cameraId;
      startCaptureOnCameraThread(null);
  }

  private void restartCaptureOnCameraThread() {
      stopCaptureOnCameraThread(false, null);
      startCaptureOnCameraThread(null);
  }

  private void stopCaptureOnCameraThread(
      boolean stopCameraThread,
      Exchanger<Boolean> result) {
    if (camera == null) {
      throw new RuntimeException("Camera is already stopped!");
    }
    Throwable error;
    try {
      camera.stopPreview();
      camera.setPreviewCallbackWithBuffer(null);
      if (localPreview != null) {
        localPreview.removeCallback(this);
        camera.setPreviewDisplay(null);
      } else {
        camera.setPreviewTexture(null);
        dummyCameraSurfaceTexture = null;
        if (cameraGlTextures != null) {
          GLES20.glDeleteTextures(1, cameraGlTextures, 0);
          cameraGlTextures = null;
        }
      }
      camera.release();
      camera = null;
      if ( result != null )
          exchange(result, true);
      if ( stopCameraThread )
          Looper.myLooper().quit();
      return;
    } catch (IOException e) {
      error = e;
    } catch (RuntimeException e) {
      error = e;
    }
    Log.e(TAG, "Failed to stop camera", error);
    if ( result != null )
        exchange(result, false);
    if ( stopCameraThread )
        Looper.myLooper().quit();
  }

  private int getDeviceOrientation() {
    int orientation = 0;
    if (context != null) {
      WindowManager wm = (WindowManager) context.getSystemService(
          Context.WINDOW_SERVICE);
      switch(wm.getDefaultDisplay().getRotation()) {
        case Surface.ROTATION_90:
          orientation = 90;
          break;
        case Surface.ROTATION_180:
          orientation = 180;
          break;
        case Surface.ROTATION_270:
          orientation = 270;
          break;
        case Surface.ROTATION_0:
        default:
          orientation = 0;
          break;
      }
    }
    return orientation;
  }

  private native void ProvideCameraFrame(
      byte[] data, int length, int rotation, long timeStamp, long captureObject);

  // Called on cameraThread so must not "synchronized".
  @Override
  public void onPreviewFrame(byte[] data, Camera callbackCamera) {
    if (Thread.currentThread() != cameraThread) {
      throw new RuntimeException("Camera callback not on camera thread?!?");
    }
    if (camera == null) {
      return;
    }
    if (camera != callbackCamera) {
      throw new RuntimeException("Unexpected camera in callback!");
    }
    frameCount++;
    long captureTimeMs = SystemClock.elapsedRealtime();
    if (frameCount > 1) {
      double durationMs = captureTimeMs - lastCaptureTimeMs;
      averageDurationMs = 0.9 * averageDurationMs + 0.1 * durationMs;
      if ((frameCount % 30) == 0) {
        Log.d(TAG, "Camera TS " + captureTimeMs +
            ". Duration: " + (int)durationMs + " ms. FPS: " +
            (int) (1000 / averageDurationMs + 0.5));
      }
    }
    lastCaptureTimeMs = captureTimeMs;

    updateOrientation();

    ProvideCameraFrame(data, data.length, orientation,
        captureTimeMs, native_capturer);
    camera.addCallbackBuffer(data);
  }

    private synchronized void updateOrientation() {
        int rotation = getDeviceOrientation();
        if (info.facing == Camera.CameraInfo.CAMERA_FACING_BACK) {
            rotation = 360 - rotation;
        }
        rotation = (info.orientation + rotation) % 360;
        if ( rotation != orientation ) {
            orientation = rotation;
            setPreviewRotation( rotation );
        }
    }

  // Sets the rotation of the preview render window.
  // Does not affect the captured video image.
  // Called by native code.
  private synchronized void setPreviewRotation(final int rotation) {

    int resultRotation = 0;
    if (info.facing == Camera.CameraInfo.CAMERA_FACING_FRONT) {
      // This is a front facing camera.  SetDisplayOrientation will flip
      // the image horizontally before doing the rotation.
      resultRotation = ( 360 - rotation ) % 360; // Compensate for the mirror.
    } else {
      // Back-facing camera.
      resultRotation = rotation;
    }

    if (camera != null) {
        camera.setDisplayOrientation(resultRotation);
    }

    if ( resultRotation != previewOrientation ) {
        new Handler(Looper.getMainLooper()).post(
                new Runnable() {
                    @Override public void run() {
                        if ( eventHandler != null ) {
                            try {
                                eventHandler.onCapturerOrientationChange();
                            } catch (Exception e) {
                                Log.e( TAG, "Error when calling onOrientationChange handler", e );
                            }

                        }}
                }
        );
        previewOrientation = resultRotation;
    }
  }
/*
  private void setPreviewRotationOnCameraThread(
      int rotation, Exchanger<IOException> result) {
    Log.v(TAG, "setPreviewRotationOnCameraThread:" + rotation);

    setPreviewRotation( rotation );

    exchange(result, null);
  }
*/
  @Override
  public synchronized void surfaceChanged(
      SurfaceHolder holder, int format, int width, int height) {
    Log.d(TAG, "VideoCaptureAndroid::surfaceChanged ignored: " +
        format + ": " + width + "x" + height);
  }

  @Override
  public synchronized void surfaceCreated(final SurfaceHolder holder) {
    Log.d(TAG, "VideoCaptureAndroid::surfaceCreated");
    if (camera == null || cameraThreadHandler == null) {
      return;
    }
    final Exchanger<IOException> result = new Exchanger<IOException>();
    cameraThreadHandler.post(new Runnable() {
        @Override public void run() {
          setPreviewDisplayOnCameraThread(holder, result);
        }
      });
    IOException e = exchange(result, null);  // |null| is a dummy value here.
    if (e != null) {
      throw new RuntimeException(e);
    }
  }

  @Override
  public synchronized void surfaceDestroyed(SurfaceHolder holder) {
    Log.d(TAG, "VideoCaptureAndroid::surfaceDestroyed");
    if (camera == null || cameraThreadHandler == null) {
      return;
    }
    final Exchanger<IOException> result = new Exchanger<IOException>();
    cameraThreadHandler.post(new Runnable() {
        @Override public void run() {
          setPreviewDisplayOnCameraThread(null, result);
        }
      });
    IOException e = exchange(result, null);  // |null| is a dummy value here.
    if (e != null) {
      throw new RuntimeException(e);
    }
  }

  private void setPreviewDisplayOnCameraThread(
      SurfaceHolder holder, Exchanger<IOException> result) {

    if ( dummyCameraSurfaceTexture != null ) {
        restartCaptureOnCameraThread();
    } else {
        try {
            camera.setPreviewDisplay(holder);
        } catch (IOException e) {
            exchange(result, e);
            return;
        }
    }
    exchange(result, null);
    return;
  }

  // Exchanges |value| with |exchanger|, converting InterruptedExceptions to
  // RuntimeExceptions (since we expect never to see these).
  private static <T> T exchange(Exchanger<T> exchanger, T value) {
    try {
      return exchanger.exchange(value);
    } catch (InterruptedException e) {
      throw new RuntimeException(e);
    }
  }
}
