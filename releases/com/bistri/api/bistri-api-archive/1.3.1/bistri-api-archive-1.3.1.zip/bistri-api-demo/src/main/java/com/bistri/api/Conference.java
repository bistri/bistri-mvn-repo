package com.bistri.api;

import android.content.Context;
import android.hardware.Camera;
import android.hardware.Camera.CameraInfo;
import android.media.AudioManager;
import android.os.Build;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.SurfaceView;
import com.bistri.api.internal.DataStreamBase;
import com.bistri.api.internal.MediaStreamBase;
import com.bistri.api.internal.PeerStreamBase;
import com.bistri.api.internal.Tool;

import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import com.bistri.api.internal.Constants;

import org.webrtc.videoengine.VideoCaptureAndroid;

import java.net.URI;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

public class Conference
{
    public static final int CONNECTION_EVENT = 0;

    public static final int CALL_ERROR = 1;

    public static final int CONF_EVENT = 2;

    public static final int ROOM_MEMBERS = 3;

    /**
     * Room member. Also known as a peer.
     */
    public interface Member
    {
        /**
         * Identifier
         * @return identifier
         */
        String id();
        /**
         * Name
         * @return member name
         */
        String name();
    }

    /**
     * Conference event listener
     */
    public interface Listener
    {
        /**
         * Callback called on connection event
         *
         * @param state (Conference.Status)
         */
        void onConnectionEvent( Conference.Status state );

        /**
         * Callback called on error event
         *
         * @param error (Conference.ErrorEvent)
         */
        void onError( ErrorEvent error );

        /**
         * Callback called when a room is joined
         *
         * @param roomName (String)
         */
        void onRoomJoined( String roomName );

        /**
         * Callback called when the current room is quitted
         *
         * @param roomName (String)
         */
        void onRoomQuitted( String roomName );

        /**
         * Callback called when a ne peer is available
         *
         * @param peerStream (PeerStream)
         */
        void onNewPeer( PeerStream peerStream );

        /**
         * Callback called when a peer has left the room
         *
         * @param peerStream (PeerStream)
         */
        void onRemovedPeer( PeerStream peerStream );

        /**
         * Callback called when a presence is received (fired by GetPresence).
         *
         * @param peerId (String) peer identifier.
         * @param presence (Presence)
         */
        void onPresence( String peerId, Presence presence );

        /**
         * Callback called when a presence is received (fired by GetPresence).
         *
         * @param peerId (String) peer identifier.
         * @param peerName (String) peer name.
         * @param room (String) room name.
         * @param callEvent (String) call event.
         */
        void onIncomingRequest(String peerId, String peerName, String room, String callEvent);

        /**
         * Callback called when getMembers result is ready
         *
         * @param roomName (String)
         * @param members (ArrayList%3CConference.Member%3E)
         */
        void onRoomMembers(String roomName, ArrayList<Member> members);
    }

    //      Local Event Types
    public enum ErrorEvent
    {
        NO_ERROR,
        CONNECTION_ERROR;

        private static final ErrorEvent[] errorEventValues = ErrorEvent.values();

        public static ErrorEvent fromInteger( int i )
        {
            return errorEventValues[i];
        }
    }

    /**
     * Room event
     */
    public enum RoomEvent
    {
        /**
         * We have joined the room
         */
        JOINED,
        /**
         * We have left the room
         */
        QUIT,
        /**
         * A member join the room
         */
        MEMBER_JOIN,
        /**
         * A member left the room
         */
        MEMBER_LEAVE;

        private static final RoomEvent[] roomEventValues = RoomEvent.values();

        /**
         * Initialize from integer
         *
         * @param i room event id
         * @return the room event
         */
        public static RoomEvent fromInteger( int i )
        {
            return roomEventValues[i];
        }
    }

    /**
     * Connection status
     */
    public enum Status
    {
        /**
         * Disconnected
         */
        DISCONNECTED,
        /**
         * Connecting
         */
        CONNECTING,
        /**
         * Connecting, send authentication request
         */
        CONNECTING_SENDREQUEST,
        /**
         * Connected
         */
        CONNECTED;

        private static final Status[] connectionEventValues = Status.values();

        /**
         * Initialize from integer
         *
         * @param i status id
         * @return the status
         */
        public static Status fromInteger( int i )
        {
            return connectionEventValues[i];
        }
    }

    /**
     * User presence
     */
    public enum Presence
    {
        /**
         * Online
         */
        ONLINE,
        /**
         * Away
         */
        AWAY,
        /**
         * Bysy
         */
        BUSY,
        /**
         * Offline
         */
        OFFLINE;

        public String toString() {
            switch (this) {
                case ONLINE: return "online";
                case AWAY: return "away";
                case BUSY: return "busy";
                case OFFLINE: return "offline";
            }
            return super.toString();
        }

        public static Presence fromString( String presence ) {
            if ( presence.equalsIgnoreCase("online") )
                return ONLINE;
            if ( presence.equalsIgnoreCase("away") )
                return AWAY;
            if ( presence.equalsIgnoreCase("busy") )
                return BUSY;
            return OFFLINE;
        }
    }

    /**
     * General options
     */
    public enum GeneralOption {
        /**
         * Specify a custom open_gl render
         */
        GL_RENDERER
    }

    /**
     * Video options
     */
    public enum VideoOption {
        /**
         * Set maximum width
         */
        MAX_WIDTH,
        /**
         * Set maximum height
         */
        MAX_HEIGHT,
        /**
         * Set maximum frame rate
         */
        MAX_FRAME_RATE
    }

    /**
     * Audio options
     */
    public enum AudioOption {
        /**
         * Set the preferred audio codec
         */
        PREFERRED_CODEC,
        /**
         * Set the preferred audio codec clock rate
         */
        PREFERRED_CODEC_CLOCKRATE
    }

    /**
     * Audio codec available
     */
    public enum AudioCodec {
        /**
         * The IETF Opus codec
         */
        OPUS,
        /**
         *  internet Speech Audio Codec
         */
        ISAC,
        /**
         *  Pulse Code Modulation μ-law
         */
        PCMU,
        /**
         *  Pulse Code Modulation a-law
         */
        PCMA,
        /**
         *  Comfort Noise
         */
        CN;
        /**
         * Serialize value
         */
        public String toString(){
            switch( this ) {
                case ISAC: return "isac";
                case PCMU: return "pcmu";
                case PCMA: return "pcma";
                case CN: return "cn";
            }
            return "opus";
        }
    }


    // Library native function
    private native void nativeInit( Context ctx, String device_info );

    private native void nativeConnect( String app_id, String app_key, String user_name, String user_id );

    private native String nativeGetUserId();

    private native void nativeDisconnect();

    private native void nativeJoinRoom( String room, int maxCapacity );

    private native void nativeCall( String peer_id, String room );

    private native void nativeOpenDataStream( String peer_id, String label, String room );

    private native void nativeSetOption( String key, String value );

    private native void nativeSetCamera( int camera_id );

    private native void nativeRotateCamera( int rotation );

    private native void nativeLeaveRoom( String room );

    private native void nativeMute( String room, String peer_id, int type, boolean mute );

    private native void nativeSetView( String room, String peer_id, SurfaceView view );

    private native void nativeGetPresence( String peer_id );

    private native void nativeSetPresence( String presence );

    private native void nativeGetMembers( String room_name );

    private native void nativeRelease();

    // Members
    private static final String TAG = "Conference";

    private static final Object mutex = new Object();

    private String app_id, app_key, user_name = "", user_id = "";

    private static Conference conference = null;

    private Status state = Status.DISCONNECTED;

    private static Context context = null;

    private boolean loaded = false;

    private boolean in_room = false;

    private static final int LIMIT_RECONNECTION_ATTEMPT = 12;

    private Handler wait_reconnect_handler = null;

    private PeerStreamBase localStream = null;

    private SurfaceView localRender = null;

    private final Collection<Listener> listeners = new ArrayList<Listener>();

    private String room_name;

    private HashMap<String, PeerStreamBase> peers;

    private int currentCamera = -1;

    private Map<GeneralOption,  Object> general_options;
    private Map<AudioOption,    Object> audio_options;
    private Map<VideoOption,    Object> video_options;

    private int connectionAttempt = 0;

    private class MemberObj implements Member{
        MemberObj( String id, String name ){ this.id = id; this.name = name; }
        private String id;
        private String name;

        @Override
        public String id() {
            return id;
        }

        @Override
        public String name() {
            return name;
        }
    }

    private Conference( Context ctx )
    {
        peers = new HashMap<String, PeerStreamBase>();
        setCtx( ctx );

        general_options = new HashMap<GeneralOption, Object>();
        audio_options = new HashMap<AudioOption, Object>();
        video_options = new HashMap<VideoOption, Object>();

    }

    private void setCtx( Context ctx )
    {
        if ( ( context != ctx ) && ( ctx != null ) )
        {
            context = ctx;
            if ( checkLoaded() )
            {
                String user_agent = "bistri_api:" + Constants.API_VERSION;
                user_agent += "; os:android";
                user_agent += "/codename:" +    Build.VERSION.CODENAME;
                user_agent += "/release:" +      Build.VERSION.RELEASE;
                user_agent += "/cpu_abi:" +      Build.CPU_ABI;
                user_agent += "/model:" +        Build.MODEL;
                user_agent += "/brand:" +         Build.BRAND;
                user_agent += "/android_api:" +  Build.VERSION.SDK_INT;

                nativeInit(ctx, user_agent);
                localRender = Renderer.CreateLocalRenderer( context );
            }
        }
    }

    private void loadOptions() {

        for (GeneralOption option : general_options.keySet()) {
            if ( hasGeneralOption( option ) ) {
                switch ( option ) {
                    case GL_RENDERER:
                        // Nothing to do
                        break;
                    default:
                        Log.w( TAG, "Option not yet managed" );
                }
            }
        }
        for (AudioOption option : audio_options.keySet()) {
            if ( hasAudioOption( option ) ) {
                switch ( option ) {
                    case PREFERRED_CODEC:
                        nativeSetOption( "audio-preferred-codec", getAudioOption_string( option ) );
                        break;
                    case PREFERRED_CODEC_CLOCKRATE:
                        nativeSetOption("audio-preferred-codec-clockrate", getAudioOption_string( option ) );
                        break;
                    default:
                        Log.w( TAG, "Option not yet managed" );
                }
            }
        }
        for (VideoOption option : video_options.keySet()) {
            if ( hasVideoOption( option) ) {
                switch ( option ) {
                    case MAX_WIDTH:
                        nativeSetOption( "video-max-width", getVideoOption_string( option ) );
                        break;
                    case MAX_HEIGHT:
                        nativeSetOption( "video-max-height", getVideoOption_string( option ) );
                        break;
                    case MAX_FRAME_RATE:
                        nativeSetOption( "video-min-frame-rate", getVideoOption_string( option ) );
                        break;
                    default:
                        Log.w( TAG, "Option not yet managed" );
                }
            }
        }
    }

    private boolean checkLoaded()
    {
        if ( !loaded )
        {
            synchronized ( mutex )
            {
                try
                {
                    System.loadLibrary( "bistriapi" );
                    loaded = true;
                }
                catch ( UnsatisfiedLinkError e )
                {
                    Log.e( TAG, "Cannot load shared library!" );
                }
            }
        }

        return loaded;
    }

    public SurfaceView getLocalRender()
    {
        return localRender;
    }

    private boolean isInfoSeemsValid()
    {

        if ( app_id == null || app_id.isEmpty() ||
                app_key == null || app_key.isEmpty() )
        {
            Log.e( TAG, "Missing or incomplete API info" );
            return false;
        }

        return true;
    }

    /*
     *       library callback
     */

    @SuppressWarnings( "UnusedDeclaration" )
    private void fromNativeOnPeerEvents( int id, String peer_id, String event_name, int value_type, String value )
    {
        peerEventsHandler.sendMessage(
                peerEventsHandler.obtainMessage( 0, 0, 0, new PeerEventObj( id, peer_id, event_name, value_type, value ) ) );
    }

    @SuppressWarnings( "UnusedDeclaration" )
    private void fromNativeOnConfEvents( int type, int code, String data )
    {
        confEventsHandler.sendMessage( confEventsHandler.obtainMessage( type, code, 0, data ) );
    }
    @SuppressWarnings( "UnusedDeclaration" )
    private void fromNativeOnPresenceEvent( String peer_id, String presence ) {
        presenceEventsHandler.sendMessage(
                presenceEventsHandler.obtainMessage( 0, 0, 0, new PresenceEventObj( peer_id, presence ) ) );
    }
    @SuppressWarnings( "UnusedDeclaration" )
    private void fromNativeOnDataChannelEvents( String peer_id, String label, String event_name, Object value ) {
        dataChannelEventsHandler.sendMessage(
                dataChannelEventsHandler.obtainMessage( 0, 0, 0, new DataChannelEventObj( peer_id, label, event_name, value ) )
        );
    }

    @SuppressWarnings( "UnusedDeclaration" )
    private void fromNativeOnGeo( String host, String sid ) {
        try {
            HttpClient client = new DefaultHttpClient();
            HttpGet request = new HttpGet();

            String uri =
                    "https://userinfo" + host + "/info?" +
                    "socketid=" + URLEncoder.encode( sid, "utf8" ) +
                    "&appid=" + URLEncoder.encode( app_id, "utf8" ) +
                    "&appkey=" + URLEncoder.encode( app_key, "utf8" );

            request.setURI( new URI( uri ) );

            client.execute(request);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /*
    *       Library callbacks handlers
    */
    private class PresenceEventObj
    {
        public String peerId;
        public String presence;

        PresenceEventObj( String peerId, String presence ){
            this.peerId = peerId;
            this.presence = presence;
        }
    }

    private class PeerEventObj
    {
        public int id;
        public String peerId;
        public String name;
        public int valueType;
        public String value;

        PeerEventObj( int id, String peerId, String name, int valueType, String value )
        {
            this.id = id;
            this.peerId = peerId;
            this.name = name;
            this.valueType = valueType;
            this.value = value;
        }
    }

    private class DataChannelEventObj
    {
        public String peerId;

        public String label;

        public String name;

        public Object value;

        DataChannelEventObj( String peerId, String label, String name, Object value )
        {
            this.peerId = peerId;
            this.label = label;
            this.name = name;
            this.value = value;
        }
    }

    private Handler peerEventsHandler = new Handler()
    {
        @Override
        public void handleMessage( Message msg )
        {
            PeerEventObj evt = (PeerEventObj) msg.obj;
            processOnPeerEvents( evt.id, evt.peerId, evt.name, evt.valueType, evt.value );
        }
    };

    private Handler dataChannelEventsHandler = new Handler()
    {
        @Override
        public void handleMessage( Message msg )
        {
            DataChannelEventObj evt = (DataChannelEventObj) msg.obj;
            processOnDataChannelEvents(evt.peerId, evt.label, evt.name, evt.value);
        }
    };

    private Handler confEventsHandler = new Handler()
    {
        @Override
        public void handleMessage( Message msg )
        {
            processOnConfEvents( msg.what, msg.arg1, (String) msg.obj );
        }
    };

    private Handler presenceEventsHandler = new Handler()
    {
        @Override
        public void handleMessage( Message msg )
        {
            PresenceEventObj evt = (PresenceEventObj) msg.obj;
            processOnPresence( evt.peerId, evt.presence );
        }
    };
    /*
    *       Process library callbacks
    */
    private enum PeerEvent
    {
        new_peer, removed_peer, media, media_ratio, incoming_request;
    }

    private enum ConfEvent
    {
        in_room, out_room
    }


    private void processOnPeerEvents( int stream_id, String peer_id, String event_name, int value_type, String value )
    {
        PeerEvent event;
        PeerStreamBase ps;
        try
        {
            event = PeerEvent.valueOf( event_name );
        }
        catch ( IllegalArgumentException e )
        {
            Log.w( "Don't know event " + event_name, e );
            return;
        }
        switch ( event )
        {
            case new_peer:
                ps = new PeerStreamBase( peer_id );
                peers.put( peer_id, ps );

                if ( ps.isLocal() )
                {
                    localStream = ps;
                }

                processOnNewPeer( getPeerStream( peer_id ) );
                break;
            case removed_peer:
                processOnRemovedPeer( peers.remove( peer_id ) );
                break;
            case media:
                if ( !checkStream( peer_id ) )
                {
                    return;
                }
                peers.get( peer_id ).setMedia( stream_id );
                break;
            case media_ratio:
                ps = peers.get( peer_id );
                if ( ps == null ) return;
                MediaStreamBase ms = ps.getMediaStreamBase();
                if ( ms != null ) {
                    ms.setVideoRatio(Float.parseFloat(value));
                }
                break;
            case incoming_request:
                String peer_name, room, call_event;

                try {
                    JSONObject response = new JSONObject( value );
                    room = response.getString( "room" );
                    peer_name = response.getString( "name" );
                    call_event = response.getString( "event" );
                } catch (JSONException e) {
                    Log.e(TAG, "Json response error", e);
                    return;
                }
                processOnIncomingRequest(peer_id, peer_name, room, call_event);
                break;
            default:
        }
    }

    private void processOnDataChannelEvents( String peer_id, String label, String event_name, Object event_value) {
        DataStreamBase.Event event;
        PeerStreamBase ps;
        try
        {
            event = DataStreamBase.Event.valueOf( event_name );
        }
        catch ( IllegalArgumentException e )
        {
            Log.w( "Don't know event " + event_name, e );
            return;
        }

        ps = peers.get( peer_id );
        if ( ps == null ) {
            Log.e( TAG, "Peer not found" );
            return;
        }

        if ( event == DataStreamBase.Event.create ) {
            ps.setDataChannel( label );
        }

        ps.onDataStreamEvent( event, label, event_value );
    }

    private boolean checkStream( String peer_id )
    {
        PeerStreamBase ps = peers.get( peer_id );
        if ( ps == null )
        {
            Log.e( TAG, "Unknown PeerStreamBase. Peer id :" + peer_id );
        }
        return ps != null;
    }

    private void cancelReconnection() {
        connectionAttempt=0;

        if ( wait_reconnect_handler != null ) {
            wait_reconnect_handler.removeCallbacks(delayedConnect);
            wait_reconnect_handler = null;
        }
    }

    private void processOnConfEvents( int type, int code, String data )
    {
        //Log.v( TAG, "onConfEvents type:" + type + " code:" + code + " data:" + data );

        switch ( type )
        {

            case CONNECTION_EVENT:

                Status new_state = Status.fromInteger( code );
                state = new_state;

                Log.i( TAG, "CONNECTION_EVENT " + new_state );


                if ( new_state == Status.CONNECTED ) {
                    cancelReconnection();
                }

                for ( Listener listener : listeners )
                {
                    try
                    {
                        in_room = false;
                        listener.onConnectionEvent( new_state );
                    }
                    catch ( Exception e )
                    {
                        Log.e( TAG, "Error when calling onConnectionEvent", e );
                    }
                }
                break;

            case CALL_ERROR:
                ErrorEvent err = ErrorEvent.fromInteger( code );
                //Log.e( TAG, "CALL_ERROR " + err );

                if ( err == ErrorEvent.CONNECTION_ERROR ) {
                    connect();
                }

                for ( Listener listener : listeners )
                {
                    try
                    {
                        listener.onError( err );
                    }
                    catch ( Exception e )
                    {
                        Log.e( TAG, "Error when calling handleErrorEvent", e );
                    }
                }
                break;

            case CONF_EVENT:

                ConfEvent event;
                String room;
                try {
                    JSONObject response = new JSONObject( data );
                    room = response.getString( "room" );
                    event = ConfEvent.valueOf( response.getString( "event" ) );
                } catch ( IllegalArgumentException e ) {
                    Log.w( "Don't know event " + data, e );
                    return;
                } catch (JSONException e) {
                    Log.w("Can't parse event " + data, e);
                    return;
                }

                switch ( event )
                {
                    case in_room:
                        in_room = true;
                        processOnRoomJoined( room );
                        break;
                    case out_room:
                        in_room = false;
                        localStream = null;
                        processOnRoomQuited( room );
                        break;
                }
                break;

            case ROOM_MEMBERS:
                try {
                    JSONObject response = new JSONObject( data );
                    room = response.getString( "room" );
                    JSONArray json_members = response.getJSONArray("members");
                    ArrayList<Member> members = new ArrayList<Member>();

                    int len = json_members.length();
                    for( int i=0; i<len; i++) {
                        JSONObject obj = (JSONObject) json_members.get( i );
                        String id = obj.getString( "id" );
                        String name = obj.getString( "name" );
                        members.add( new MemberObj( id, name ) );
                    }

                    for ( Listener listener : listeners ) {
                        try {
                            listener.onRoomMembers( room, members );
                        } catch ( Exception e ) {
                            Log.e( TAG, "Error when calling onRoomMembers", e );
                        }
                    }

                } catch ( IllegalArgumentException e ) {
                    Log.w( "Don't know event " + data, e );
                    return;
                } catch (JSONException e) {
                    Log.w("Can't parse event " + data, e);
                    return;
                }
                break;


            default:
                Log.e( TAG, "onConfEvents event not managed" );
        }
    }

    private void processOnRoomJoined(String room)
    {
        for ( Listener listener : listeners )
        {
            try
            {
                listener.onRoomJoined( room_name );
            }
            catch ( Exception e )
            {
                Log.e( TAG, "Error when calling onRoomJoined", e );
            }
        }
    }

    private void processOnRoomQuited( String room )
    {
        for ( Listener listener : listeners )
        {
            try
            {
                listener.onRoomQuitted( room );
            }
            catch ( Exception e )
            {
                Log.e( TAG, "Error when calling onRoomJoined", e );
            }
        }
    }

    private void processOnNewPeer( PeerStream peerStream )
    {
        for ( Listener listener : listeners )
        {
            try
            {
                listener.onNewPeer( peerStream );
            }
            catch ( Exception e )
            {
                Log.e( TAG, "Error when calling processOnNewPeer", e );
            }
        }
    }

    private void processOnRemovedPeer( PeerStream peerStream )
    {
        for ( Listener listener : listeners )
        {
            try
            {
                listener.onRemovedPeer(peerStream);
            }
            catch ( Exception e )
            {
                Log.e( TAG, "Error when calling onRemovedPeer", e );
            }
        }
    }

    private void processOnPresence( String peer_id, String presence )
    {
        for ( Listener listener : listeners )
        {
            try
            {
                listener.onPresence(peer_id, Presence.fromString(presence));
            }
            catch ( Exception e )
            {
                Log.e( TAG, "Error when calling onRemovedPeer", e );
            }
        }
    }

    private void processOnIncomingRequest( String peer_id, String peer_name, String room, String call_event ) {
        for ( Listener listener : listeners )
        {

            try
            {
                listener.onIncomingRequest( peer_id, peer_name, room, call_event );
            }
            catch ( Exception e )
            {
                Log.e( TAG, "Error when calling onIncomingRequest", e );
            }
        }
    }

    /**
     * Get the number of available camera.
     *
     * <pre>
     * {@code
     *     // Usage
     *     int nbCamera = bistriConference.getCameraNb();
     * }
     * </pre>
     *
     * @return camera number.
     */
    public int getCameraNb() {
        return Camera.getNumberOfCameras();
    }

    /**
     * Get information about available cameras.
     *
     * <pre>
     * {@code
     *     // Usage
     *     ArrayList<CameraInfo> cameraInfoList = bistriConference.getCameraInfos();
     * }
     * </pre>
     *
     * @return an ArrayList of CameraInfo.
     */
    public ArrayList<CameraInfo> getCameraInfos()
    {
        int nbCameras = getCameraNb();
        ArrayList<CameraInfo> cameraInfos = new ArrayList<CameraInfo>();

        for (int i = 0; i < nbCameras; i++) {
            CameraInfo info = new CameraInfo();
            Camera.getCameraInfo( i, info );
            cameraInfos.add( info );
            if ( ( currentCamera < 0 ) && ( info.facing == CameraInfo.CAMERA_FACING_FRONT ) ) {
                currentCamera = i;
            }
        }
        if ( currentCamera < 0 && nbCameras > 0)
            currentCamera = 0;

        return  cameraInfos;
    }

    /**
     * Get the instance of bistri conference object. If no previous instance already exists, a new one will be created.
     *
     * <pre>
     * {@code
     *     // Usage
     *     Conference bistriConference = Conference.getInstance( getApplicationContext() );
     * }
     * </pre>
     *
     * @param context (android.content.Context) Application context.
     * @return Conference object.
     */
    static public Conference getInstance( Context context )
    {
        if ( conference == null )
        {
            conference = new Conference( context );
        }
        else if ( Conference.context != context )
        {
            conference.setCtx( context );
        }

        return conference;
    }

    /**
     * Get the current instance of bistri conference object.
     *
     * @return Conference object or null if no previous instance already exists.
     */
    static public Conference getInstance()
    {
        return conference;
    }

    /**
     * Set credential information.
     * WARNING: Your application package name is automaticaly used as "referrer". So, to be able to use this android API, don't forget to add your package name into referrer
     *
     * <pre>
     * {@code
     *     // Usage
     *     bistriConference.setInfo( "36846eab", "4c304359baa6d0bd1f9106aaeb215f22" );
     * }
     * </pre>
     *
     * @param appId  (String) Your application Identifier
     * @param appKey (String) Your application Key
     * @return True if appId and appKey seem valid.
     */
    public boolean setInfo( String appId, String appKey)
    {
        app_id = appId;
        app_key = appKey;

        return isInfoSeemsValid();
    }

    /**
     * Set credential information.
     * WARNING: Your application package name is automaticaly used as "referrer". So, to be able to use this android API, don't forget to add your package name into referrer
     *
     * <pre>
     * {@code
     *     // Usage
     *     bistriConference.setInfo( "36846eab", "4c304359baa6d0bd1f9106aaeb215f22", userName );
     * }
     * </pre>
     *
     * @param appId  (String) Your application Identifier
     * @param appKey (String) Your application Key
     * @param userName (String) User name
     * @return True if appId and appKey seem valid.
     */
    public boolean setInfo( String appId, String appKey, String userName )
    {
        app_id = appId;
        app_key = appKey;
        user_name = userName;

        return isInfoSeemsValid();
    }

    /**
     * Set credential information.
     * WARNING: Your application package name is automaticaly used as "referrer". So, to be able to use this android API, don't forget to add your package name into referrer
     *
     * <pre>
     * {@code
     *     // Usage
     *     bistriConference.setInfo( "36846eab", "4c304359baa6d0bd1f9106aaeb215f22", userName );
     * }
     * </pre>
     *
     * @param appId  (String) Your application Identifier
     * @param appKey (String) Your application Key
     * @param userName (String) User name
     * @param userId (String) User identifier
     * @return True if appId and appKey seem valid.
     */
    public boolean setInfo( String appId, String appKey, String userName, String userId )
    {
        app_id = appId;
        app_key = appKey;
        user_name = userName;
        user_id = userId;

        return isInfoSeemsValid();
    }

    /**
     * Add a bistri conference listener.
     *
     * <pre>
     * {@code
     *     // Usage
     *     bistriConference.addListener( myListener );
     * }
     * </pre>
     *
     * @param listener (bistri.conference.Listener)
     */
    public void addListener( Listener listener )
    {
        listeners.add( listener );
    }

    /**
     * Remove a bistri conference listener.
     *
     * <pre>
     * {@code
     *     // Usage
     *     bistriConference.removeListener( myListener );
     * }
     * </pre>
     *
     * @param listener (bistri.conference.Listener)
     */
    public void removeListener( Listener listener )
    {
        listeners.remove(listener);
    }

    /**
     * Connect to bistri conference service.
     *
     * <pre>
     * {@code
     *     // Usage
     *     bistriConference.connect();
     * }
     * </pre>
     */
    public void connect()
    {
        if ( checkLoaded() )
        {

            if ( !isInfoSeemsValid() || wait_reconnect_handler != null ) {
                return;
            }

            connectionAttempt += ( connectionAttempt < LIMIT_RECONNECTION_ATTEMPT ) ? 1 : 0;
            if ( connectionAttempt == 1 ) {
                nativeConnect( app_id, app_key, user_name, user_id );
            } else {
                long wait_before_connect = Tool.fibonacci( connectionAttempt + 1 ) * 1000;

                // Need to wait a little between each connect attempt.
                wait_reconnect_handler = new Handler();
                wait_reconnect_handler.postDelayed(delayedConnect, wait_before_connect);
            }
        }
    }

    private Runnable delayedConnect = new Runnable() {
        @Override
        public void run()
        {
            nativeConnect( app_id, app_key, user_name, user_id );
            wait_reconnect_handler = null;
        }
    };

    /**
     * Disconnect.
     *
     * <pre>
     * {@code
     *     // Usage
     *     bistriConference.disconnect();
     * }
     * </pre>
     */
    public void disconnect()
    {
        if ( checkLoaded() )
        {
            cancelReconnection();
            nativeDisconnect();
        }
    }

    /**
     * Get the connection status.
     *
     * <pre>
     * {@code
     *     // Usage
     *     bistriConference.getState();
     * }
     * </pre>
     *
     * @return Status.
     */
    public Status getStatus()
    {
        return state;
    }

    /**
     * Join a room.
     *
     * <pre>
     * {@code
     *     // Usage
     *     bistriConference.join( "MyRoomName" );
     * }
     * </pre>
     *
     * @param roomName The room name you want to join. It can be an existing one, or a new one. Room name can contains only a-z,A-Z,0-9,-,_
     */
    public void join( String roomName )
    {
        if ( !roomName.matches( "[a-zA-Z0-9\\-_]+" ) )
        {
            Log.e( TAG, "Cannot join room " + roomName + " : malformed name" );
            return;
        }

        if ( checkLoaded() )
        {
            loadOptions();
            room_name = roomName;
            nativeJoinRoom( roomName, 0 );
        }
    }

    /**
     * Start a call with a remote user.
     *
     * <pre>
     * {@code
     *     // Usage
     *     bistriConference.call( peerId, "MyCallingRoom" );
     * }
     * </pre>
     *
     * @param peerId (String) peer identifier.
     * @param roomName (String) The room where the call take place. Room name can contains only a-z,A-Z,0-9,-,_
     */
    public void call( String peerId, String roomName ) {
        if ( !roomName.matches( "[a-zA-Z0-9\\-_]+" ) )
        {
            Log.e( TAG, "Cannot join room " + roomName + " : malformed name" );
            return;
        }
        if ( checkLoaded() )
        {
            loadOptions();
            room_name = roomName;
            nativeCall( peerId, roomName );
        }
    }

    /**
     * open data stream
     *
     * <pre>
     * {@code
     *     // Usage
     *     bistriConference.openDataStream( peerId, "MyDataChannel", "MyCallingRoom" );
     * }
     * </pre>
     *
     * @param peerId (String) peer identifier.
     * @param label (String) data stream label.
     * @param roomName (String) The room where the call take place. Room name can contains only a-z,A-Z,0-9,-,_
     */
    public void openDataChannel( String peerId, String label, String roomName ) {
        if ( !roomName.matches( "[a-zA-Z0-9\\-_]+" ) )
        {
            Log.e( TAG, "Cannot join room " + roomName + " : malformed name" );
            return;
        }
        if ( checkLoaded() )
        {
            loadOptions();
            room_name = roomName;
            nativeOpenDataStream( peerId, label, roomName );
        }
    }


    /**
     * Join a room without user name.
     *
     * <pre>
     * {@code
     *     // Usage
     *     bistriConference.join( "MyRoomName", 4 );
     * }
     * </pre>
     *
     * @param roomName The room name you want to join. It can be an existing one, or a new one. Room name can contains only a-z,A-Z,0-9,-,_
     * @param roomMaxCapacity The room maximum number of participants in a room by using the roomMaxCapacity parameter. Only the first person joining the room can set the limitation. By default the maximum number of participants is limited to 256
     */
    public void join( String roomName, int roomMaxCapacity )
    {
        if ( !roomName.matches( "[a-zA-Z0-9\\-_]+" ) )
        {
            Log.e( TAG, "Cannot join room " + roomName + " : malformed name" );
            return;
        }

        if ( checkLoaded() )
        {
            loadOptions();
            room_name = roomName;
            nativeJoinRoom( roomName, roomMaxCapacity );
        }
    }

    /**
     * Leave the current room.
     *
     * <pre>
     * {@code
     *     // Usage
     *     bistriConference.leave();
     * }
     * </pre>
     *
     * @param room (String) room name
     */
    public void leave( String room )
    {
        if ( checkLoaded() )
        {
            nativeLeaveRoom( room );
        }
    }

    /**
     * Check if a room is joined
     *
     * <pre>
     * {@code
     *     // Usage
     *     bistriConference.setCameraId( facingBackCameraIndex );
     * }
     * </pre>
     *
     * @param id (int) camera identifier. Also the camera index of getCameraInfos().
     */
    public void setCameraId( int id ) {
        if ( id < 0 || id >= getCameraNb() ) {
            Log.e( TAG, "Bad camera id !" );
            return;
        }
        if ( checkLoaded() )
        {
            currentCamera = id;
            nativeSetCamera( currentCamera );
            VideoCaptureAndroid.setCamera( currentCamera );
        }
    }

    /**
     * Get the current camera index. Can return -1 if setCameraId has never been called; -1 means library will
     * choose the first front-facing camera available.
     *
     * <pre>
     * {@code
     *     // Usage
     *     int index = bistriConference.getCameraId();
     * }
     * </pre>
     *
     * @return current camera index.
     */
    public int getCameraId() {
        return currentCamera;
    }

    /**
     * Return the current room name.
     *
     * <pre>
     * {@code
     *     // Usage
     *     String roomName = bistriConference.getRoomName();
     * }
     * </pre>
     *
     * @return the current room name. If no room is joined, null is returned.
     */
    public String getRoomName()
    {
        return room_name;
    }

    /**
     * Set video render view.
     *
     * <pre>
     * {@code
     *     // Usage
     *     String roomName = bistriConference.setView(peer_id, view);
     * }
     * </pre>
     *
     * @param room (String) room name
     * @param peer_id (String) peer identifier
     * @param view (SurfaceView) SurfaceView where video is rendered
     */
    public void setView( String room, String peer_id, SurfaceView view ) // Used internaly
    {
        if ( checkLoaded() )
        {
            nativeSetView(room, peer_id, view);
        }
    }

    /**
     * Return the application context that has been set with getInstance.
     *
     * <pre>
     * {@code
     *     // Usage
     *     Context ctx = bistriConference.getContext();
     * }
     * </pre>
     *
     * @return android.content.Context.
     */
    public Context getContext()
    {
        return context;
    }

    /**
     * Return the local peer stream.
     *
     * <pre>
     * {@code
     *     // Usage
     *     PeerStream localPeer = bistriConference.getLocalStream();
     * }
     * </pre>
     *
     * @return PeerStream.
     */
    public PeerStream getLocalStream()
    {
        if ( localStream == null )
        {
            localStream = new PeerStreamBase( "local" );
        }

        return localStream;
    }

    /**
     * Return a peer stream from peer ID.
     *
     * <pre>
     * {@code
     *     // Usage
     *     PeerStream peer = bistriConference.getPeerStream( remotePeerId );
     * }
     * </pre>
     *
     * @param peerId (String) peer identifier
     * @return PeerStream.
     */
    public PeerStream getPeerStream( String peerId )
    {
        return peers.get( peerId );
    }

    /**
     * Return an identifiers array of peers currently in the room.
     *
     * <pre>
     * {@code
     *     // Usage
     *     Context ctx = bistriConference.getPeerStream_Ids();
     * }
     * </pre>
     *
     * @return String[].
     */
    public String[] getPeerStream_Ids()
    {
        return peers.keySet().toArray( new String[peers.size()] );
    }

    /**
     * Set a general option.
     *
     * <pre>
     * {@code
     *     // Usage
     *     bistriConference.setGeneralOption( GeneralOption.GL_RENDERER, CustomGLRenderer.class.getName() );
     * }
     * </pre>

     * @param option (Conference.GeneralOption)
     * @param value (String) option value
     */
    public void setGeneralOption(GeneralOption option, String value) {
        switch (option) {
            case GL_RENDERER:
                general_options.put(option, value);
                return;
        }
        Log.e(TAG, "Bad type for this option");
    }

    /**
     * Check if a general option has been set.
     *
     * <pre>
     * {@code
     *     // Usage
     *     bistriConference.hasGeneralOption( GeneralOption.GL_RENDERER );
     * }
     * </pre>
     *
     * @param option (Conference.GeneralOption)
     * @return True if the given option has already been set.
     */
    public boolean hasGeneralOption( GeneralOption option ) {
        return general_options.get( option ) != null;
    }

    /**
     * Get general option has String.
     *
     * <pre>
     * {@code
     *     // Usage
     *     bistriConference.getGeneralOption_String( GeneralOption.GL_RENDERER );
     * }
     * </pre>
     *
     * @param option (Conference.GeneralOption)
     * @return value has a String if possible, null otherwise.
     */
    public String getGeneralOption_String( GeneralOption option ) {
        Object value = general_options.get(option);
        if ( value != null ) {
            switch ( option ) {
                case GL_RENDERER:
                    if ( value instanceof String ) {
                        return (String)value;
                    } else {
                        return value.toString();
                    }
            }
        }
        Log.e( TAG, "Bad returned type for this option" );
        return null;
    }

    /**
     * Set video options.
     *
     * <pre>
     * {@code
     *     // Usage
     *     bistriConference.setVideoOption( VideoOption.MAX_HEIGHT, 480 );
     * }
     * </pre>
     *
     * @param option (Conference.GeneralOption)
     * @param value (int)
     */
    public void setVideoOption(VideoOption option, int value) {
        switch ( option ) {
            case MAX_WIDTH:
            case MAX_HEIGHT:
            case MAX_FRAME_RATE:
                video_options.put( option, value );
                return;
        }
        Log.e( TAG, "Bad type for this option" );
    }

    /**
     * Check if a video option has been set.
     *
     * <pre>
     * {@code
     *     // Usage
     *     bistriConference.hasVideoOption( VideoOption.MAX_HEIGHT );
     * }
     * </pre>

     * @param option (Conference.VideoOption)
     * @return True if the given option has already been set.
     */
    public boolean hasVideoOption( VideoOption option ) {
        return video_options.get( option ) != null;
    }

    /**
     * Get video option has int.
     *
     * <pre>
     * {@code
     *     // Usage
     *     bistriConference.getVideoOption_int( VideoOption.MAX_HEIGHT );
     * }
     * </pre>
     *
     * @param option (Conference.VideoOption)
     * @return value has a String if possible, null otherwise.
     */
    public int getVideoOption_int(VideoOption option) {
        Object value = video_options.get(option);
        if ( value != null ) {
            switch (option) {
                case MAX_WIDTH:
                case MAX_HEIGHT:
                case MAX_FRAME_RATE:
                    if (value instanceof Integer) {
                        return (Integer) value;
                    }
                    break;
            }
        }
        Log.e( TAG, "Bad returned type for this option" );
        return 0;
    }

    /**
     * Get video option has String.
     *
     * <pre>
     * {@code
     *     // Usage
     *     bistriConference.getGeneralOption_String( VideoOption.MAX_HEIGHT );
     * }
     * </pre>
     *
     * @param option (Conference.VideoOption)
     * @return value has a String if possible, null otherwise.
     */
    public String getVideoOption_string(VideoOption option) {
        Object value = video_options.get(option);
        if ( value != null ) {
            switch ( option ) {
                case MAX_WIDTH:
                case MAX_HEIGHT:
                case MAX_FRAME_RATE:
                    if ( value instanceof String ) {
                        return (String)value;
                    } else {
                        return value.toString();
                    }
            }
        }
        Log.e( TAG, "Bad returned type for this option" );
        return null;
    }

    /**
     * Set audio options.
     *
     * <pre>
     * {@code
     *     // Usage
     *     bistriConference.setAudioOption( AudioOption.PREFERRED_CODEC, AudioCodec.ISAC );
     * }
     * </pre>
     *
     * @param option (Conference.AudioOption)
     * @param value (Conference.AudioCodec)
     */
    public void setAudioOption(AudioOption option, AudioCodec value) {
        switch ( option ) {
            case PREFERRED_CODEC:
                audio_options.put( option, value );
                return;
        }
        Log.e( TAG, "Bad type for this option" );
    }

    /**
     * Set audio options.
     *
     * <pre>
     * {@code
     *     // Usage
     *     bistriConference.setAudioOption( AudioOption.PREFERRED_CODEC_CLOCKRATE, 16000 );
     * }
     * </pre>
     *
     * @param option (Conference.AudioOption)
     * @param value (int)
     */
    public void setAudioOption(AudioOption option, int value) {
        switch ( option ) {
            case PREFERRED_CODEC_CLOCKRATE:
                audio_options.put( option, value );
                return;
        }
        Log.e(TAG, "Bad type for this option");
    }

    /**
     * Check if an audio option has been set.
     *
     * <pre>
     * {@code
     *     // Usage
     *     bistriConference.hasAudioOption( AudioOption.PREFERRED_CODEC );
     * }
     * </pre>
     *
     * @param option (Conference.AudioOption)
     * @return True if the given option has already been set.
     */
    public boolean hasAudioOption( AudioOption option ) {
        return audio_options.get( option ) != null;
    }

    /**
     * Get audio option has integer.
     *
     * <pre>
     * {@code
     *     // Usage
     *     int clockrate = bistriConference.getAudioOption_int( AudioOption.PREFERRED_CODEC_CLOCKRATE );
     * }
     * </pre>
     *
     * @param option (Conference.AudioOption)
     * @return int value.
     */
    public int getAudioOption_int(AudioOption option) {
        Object value = audio_options.get(option);
        if ( value != null ) {
            switch ( option ) {
                case PREFERRED_CODEC_CLOCKRATE:
                    if (value instanceof Integer) {
                        return ((Integer) value).intValue();
                    }
                    break;
            }
        }
        Log.e( TAG, "Bad returned type for this option" );
        return 0;
    }

    /**
     * Get audio option has AudioCodec enum.
     *
     * <pre>
     * {@code
     *     // Usage
     *     AudioCodec codec = bistriConference.getAudioOption_AudioCodec( AudioOption.PREFERRED_CODEC );
     * }
     * </pre>
     *
     * @param option (Conference.AudioOption)
     * @return AudioCodec value.
     */
    public AudioCodec getAudioOption_AudioCodec(AudioOption option) {
        Object value = audio_options.get(option);
        if ( value != null ) {
            switch (option) {
                case PREFERRED_CODEC:
                    if (value instanceof AudioCodec) {
                        return (AudioCodec) value;
                    }
                    break;
            }
        }
        Log.e( TAG, "Bad returned type for this option" );
        return null;
    }

    /**
     * Get audio option has String.
     *
     * <pre>
     * {@code
     *     // Usage
     *     String codec_name = bistriConference.getAudioOption_string( AudioOption.PREFERRED_CODEC );
     * }
     * </pre>
     *
     * @param option (Conference.AudioOption)
     * @return String value.
     */
    public String getAudioOption_string(AudioOption option) {
        Object value = audio_options.get(option);
        if ( value != null ) {
            switch (option) {
                case PREFERRED_CODEC:
                case PREFERRED_CODEC_CLOCKRATE:
                    if (value instanceof String) {
                        return (String) value;
                    } else {
                        return value.toString();
                    }
            }
        }
        Log.e( TAG, "Bad returned type for this option" );
        return null;
    }

    /**
     * Enable/disable loud speaker.
     *
     * <pre>
     * {@code
     *     // Usage
     *     bistriConference.setLoudspeaker( false );
     * }
     * </pre>
     *
     * @param enable (boolean)
     */
    public void setLoudspeaker(boolean enable) {

        AudioManager audioManager = (AudioManager) context.getSystemService(Context.AUDIO_SERVICE);

        if (audioManager == null) {
            Log.e(TAG, "setLoudspeaker error: no AudioManager");
            return;
        }

        int apiLevel = android.os.Build.VERSION.SDK_INT;

        if ((3 == apiLevel) || (4 == apiLevel)) {
            // 1.5 and 1.6 devices
            audioManager.setMode( enable ? AudioManager.MODE_NORMAL : AudioManager.MODE_IN_CALL);
        } else {
            // 2.x devices
            if ( android.os.Build.BRAND.equalsIgnoreCase("samsung") && ((5 == apiLevel) || (6 == apiLevel) ||  (7 == apiLevel)) ) {
                // Samsung 2.0, 2.0.1 and 2.1 devices
                if (enable) {
                    // route audio to back speaker
                    audioManager.setMode(AudioManager.MODE_IN_CALL);
                    audioManager.setSpeakerphoneOn(enable);
                } else {
                    // route audio to earpiece
                    audioManager.setSpeakerphoneOn(enable);
                    audioManager.setMode(AudioManager.MODE_NORMAL);
                }
            } else {
                audioManager.setSpeakerphoneOn(enable);
            }
        }
    }

    /**
     * Get your own user identifier. This identifier is set by the conference server after been connected.
     *
     * <pre>
     * {@code
     *     // Usage
     *     String myOwnUserId = bistriConference.getUserId();
     * }
     * </pre>
     *
     * @return String identifier if any, it return null otherwise.
     */
    public String getUserId() {

        return nativeGetUserId();
    }

    /**
     * Set your own presence.
     *
     * <pre>
     * {@code
     *     // Usage
     *     bistriConference.setPresence( Presence.AWAY );
     * }
     * </pre>
     *
     * @param presence (Presence)
     * @see Presence
     */
    public void setPresence( Presence presence ) {
        nativeSetPresence( presence.toString() );
    }

    /**
     * Get presence of a remote peer. Presence is returned asynchronously using method "onPresence()" of Conference.Listener.
     *
     * <pre>
     * {@code
     *     // Usage
     *     bistriConference.getPresence( remotePeerId );
     * }
     * </pre>
     *
     * @param remoteUserId (String) remote user identifier
     * @see Conference.Listener for response
     */
    public void getPresence( String remoteUserId) {
        nativeGetPresence( remoteUserId );
    }

    /**
     * Get members of a room.
     *
     * <pre>
     * {@code
     *     // Usage
     *     bistriConference.getMembers( myRoomName );
     * }
     * </pre>
     *
     * @param roomName (String) The room name
     * @see Conference.Listener for response?
     */
    public void getMembers( String roomName) {
        nativeGetMembers( roomName );
    }
}
