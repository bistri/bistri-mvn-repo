package com.bistri.api;

import java.nio.ByteBuffer;

public interface DataStream
{

    /**
     * Connection status
     */
    public enum Status
    {
        /**
         * Channel not ready
         */
        PENDING,
        /**
         * Channel connected
         */
        OPEN,
        /**
         * Channel closed
         */
        CLOSED;
    }

    /**
     * DataStream handler.
     */
    public interface Handler
    {
        /**
         * Called when the DataStream is open and ready to send/receive data.
         *
         * @param myself data stream
         */
        void onOpen( DataStream myself );

        /**
         * Called when a message (data) is received
         *
         * @param myself data stream
         * @param message The message receive
         * @param binary True if the message is binary
         */
        void onMessage( DataStream myself, ByteBuffer message, boolean binary );

        /**
         * Called when the DataStream is closed
         *
         * @param myself data stream
         */
        void onClose( DataStream myself );

        /**
         * Called when an error occurred
         *
         * @param myself data stream
         * @param error (String) The error
         */
        void onError( DataStream myself, String error );
    }

    /**
     * Set an handle for this data stream.
     *
     * <pre>
     * {@code
     *     // Usage
     *     dataStream.setHandler( handler );
     * }
     * </pre>
     *
     * @param handler (DataStream.Handler) data stream handler
     */
    void setHandler( Handler handler );

    /**
     * Send data through DataStream
     *
     * <pre>
     * {@code
     *     // Usage
     *     dataStream.send( message, true );
     * }
     * </pre>
     *
     * @param message (ByteBuffer) data to send
     * @param binary (boolean) Binary flag. Set to false for a string
     */
    void send( ByteBuffer message, boolean binary );

    /**
     * Send data through DataStream
     * @param message (String) string data to send
     *
     * <pre>
     * {@code
     *     // Usage
     *     dataStream.send( "hello world" );
     * }
     * </pre>
     */
    void send(String message);

    /**
     * Get DataStream label
     *
     * <pre>
     * {@code
     *     // Usage
     *     String label = dataStream.getLabel();
     * }
     * </pre>
     * @return the label String.
     */
    String getLabel();

    /**
     * Get the status of DataStream
     *
     * <pre>
     * {@code
     *     // Usage
     *     Status status = dataStream.getStatus();
     * }
     * </pre>
     * @return DataStream.Status of this DataStream
     */
    Status getStatus();

    /**
     * Close DataStream
     *
     * <pre>
     * {@code
     *     // Usage
     *     dataStream.close();
     * }
     * </pre>
     */
    void close();
}
