package com.bistri.api.internal;

import com.bistri.api.DataStream;
import com.bistri.api.MediaStream;
import com.bistri.api.PeerStream;
import com.bistri.api.internal.MediaStreamBase;

import java.nio.ByteBuffer;
import java.util.HashMap;
import java.util.Map;

public class PeerStreamBase
    implements PeerStream
{
    private String peer_id;

    private MediaStreamBase mediaStream = null;

    private Handler handler;

    private Map<String, DataStream> dataChannels;

    private native void nativeOpenDataChannel( String peer_id, String label );


    public PeerStreamBase( String pid )
    {
        peer_id = pid;
        dataChannels = new HashMap<String, DataStream>();
    }

    public boolean isLocal()
    {
        return peer_id.equals( "local" );
    }

    @Override
    public boolean hasMedia()
    {
        return mediaStream != null;
    }

    @Override
    public void setHandler( Handler handler )
    {
        this.handler = handler;
    }

    public MediaStream getMedia()
    {
        return mediaStream;
    }

    @Override
    public DataStream openDataChannel(String label) {

        nativeOpenDataChannel( peer_id, label );

        setDataChannel( label );
        DataStreamBase dc = (DataStreamBase)dataChannels.get( label );

        return dc;
    }

    @Override
    public DataStream getDataChannel(String label) {
        return dataChannels.get( label );
    }

    @Override
    public Map<String, DataStream> getDataChannels() {
        return dataChannels;
    }

    public void setMedia( int streamId ) {
        if ( mediaStream == null ) {
            mediaStream = new MediaStreamBase( streamId, peer_id );

            if ( handler != null ) {
                handler.onMediaStream( peer_id, mediaStream );
            }
        }
    }

    public void setDataChannel( String label ) {
        DataStreamBase dc = (DataStreamBase)dataChannels.get( label );
        if ( dc != null ) {
            // Already exists
            return;
        }
        dc = new DataStreamBase( peer_id, label );
        dataChannels.put( label, dc );

        if ( handler != null ) {
            handler.onDataStream(peer_id, dc);
        }
    }

    public MediaStreamBase getMediaStreamBase()
    {
        return mediaStream;
    }

    public String getId()
    {
        return peer_id;
    }

    public void onDataStreamEvent(DataStreamBase.Event event, String label, Object event_value) {

        DataStreamBase ds = (DataStreamBase)dataChannels.get( label );
        if ( ds == null ) {
            return;
        }

        ds.onEvent( event, event_value );

        if ( event == DataStreamBase.Event.close ) {
            dataChannels.remove( label );
        }
    }
}
