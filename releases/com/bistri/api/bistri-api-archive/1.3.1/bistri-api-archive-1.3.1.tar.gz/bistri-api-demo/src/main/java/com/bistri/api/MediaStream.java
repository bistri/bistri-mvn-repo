package com.bistri.api;

import android.view.SurfaceView;

public interface MediaStream
{

    /**
     * MediaStream handler.
     */
    public interface Handler
    {
        /**
         * Called when the video ratio change. This can happen when a phone is rotate from landscape to portrait.
         *
         * @param peer_id (String) The id of the peer
         * @param mediaStream The media stream
         * @param ratio (float) the ratio of the video
         */
        void onVideoRatioChange( String peer_id, MediaStream mediaStream, float ratio );
    }

    /**
     * Set an handle for this media stream.
     *
     * @param handler (MediaStream.Handler) media stream handler
     * 
     * <pre>
     * {@code
     *     // Usage
     *     mediaStream.setHandler( handler );
     * }
     * </pre>
     */
    void setHandler( Handler handler );

    /**
     * Return the surface view used to render the media stream video.
     * 
     * <pre>
     * {@code
     *     // Usage
     *     SurfaceView surface = mediaStream.getRender();
     * }
     * </pre>
     *
     * @return SurfaceView.
     */
    SurfaceView getRender();

    /**
     * Test if this media stream has video.
     * 
     * <pre>
     * {@code
     *     // Usage
     *     if ( mediaStream.hasVideo() ) { ... }
     * }
     * </pre>
     *
     * @return True if the media stream has video, false otherwise.
     */
    boolean hasVideo();


    /**
     * Test if this media stream has audio.
     *
     * <pre>
     * {@code
     *     // Usage
     *     if ( mediaStream.hasAudio() ) { ... }
     * }
     * </pre>
     *
     * @return True if the media stream has audio, false otherwise.
     */
    boolean hasAudio();
    /**
     * Return the ratio of the video ( width / height ).
     * 
     * <pre>
     * {@code
     *     // Usage
     *     float ratio = mediaStream.getVideoRatio();
     * }
     * </pre>
     *
     * @return float video ratio.
     */
    float getVideoRatio();

    /**
     * Mute audio of this stream (if any).
     * 
     * <pre>
     * {@code
     *     // Usage
     *     float ratio = mediaStream.muteAudio(true);
     * }
     * </pre>
     *
     * @param mute (boolean) Set it to true to mute the audio
     */
    void muteAudio( boolean mute );

    /**
     * Mute video of this stream (if any).
     * 
     * <pre>
     * {@code
     *     // Usage
     *     float ratio = mediaStream.muteVideo(true);
     * }
     * </pre>
     *
     * @param mute (boolean) Set it to true to mute the video
     */
    void muteVideo( boolean mute );

    /**
     * Check if audio of this stream is muted or not.
     * 
     * <pre>
     * {@code
     *     // Usage
     *     boolean audioMuteStatus = mediaStream.isAudioMute();
     * }
     * </pre>
     *
     * @return True if audio is muted.
     */
    boolean isAudioMute();

    /**
     * Check if video of this stream is muted or not.
     * 
     * <pre>
     * {@code
     *     // Usage
     *     boolean videoMuteStatus = mediaStream.isVideoMute();
     * }
     * </pre>
     *
     * @return True if video is muted.
     */
    boolean isVideoMute();

    /**
     * Get peer identifier of this MediaStream
     * 
     * <pre>
     * {@code
     *     // Usage
     *     String peerId = mediaStream.getPeerId();
     * }
     * </pre>
     *
     * @return String identifier.
     */
    String getPeerId();
}
