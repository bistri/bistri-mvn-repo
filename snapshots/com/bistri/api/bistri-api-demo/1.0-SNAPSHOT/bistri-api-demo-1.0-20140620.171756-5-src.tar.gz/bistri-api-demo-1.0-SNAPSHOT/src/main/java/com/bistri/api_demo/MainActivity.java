package com.bistri.api_demo;


import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.text.InputFilter;
import android.text.Spanned;
import android.util.Log;
import android.view.KeyEvent;
import android.view.SurfaceView;
import android.view.View;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.bistri.api.Conference;
import com.bistri.api.Conference.ErrorEvent;
import com.bistri.api.Conference.Status;
import com.bistri.api.MediaStream;
import com.bistri.api.PeerStream;

public class MainActivity extends Activity
    implements View.OnClickListener, Conference.Listener, PeerStream.Handler, MediaStream.Handler {
    // Static Fields
    private static final String TAG = "MainActivity";

    // Members
    EditText room_name;
    Button join_button;
    TextView status;
    ImageView loader_spinner;
    RelativeLayout call_layout;
    LinearLayout room_layout;
    //Spinner select_camera;

    private Conference conference;

    /*
    *       Activity Management
    */

    @Override
    protected void onCreate (Bundle savedInstanceState)
    {
        super.onCreate( savedInstanceState );

        setContentView(R.layout.demo);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        room_name = ( EditText )findViewById( R.id.room_name );
        join_button = ( Button )findViewById( R.id.join_button );
        status = ( TextView )findViewById( R.id.status );
        loader_spinner = ( ImageView )findViewById( R.id.loader_spinner );
        call_layout = ( RelativeLayout )findViewById( R.id.call_layout );
        room_layout = ( LinearLayout )findViewById( R.id.room_layout );
        //select_camera = ( Spinner )findViewById( R.id.select_camera );

        // Conference
        conference = Conference.getInstance( getApplicationContext() );
        conference.setInfo( "38077edb", "4f304359baa6d0fd1f9106aaeb116f33" );
        conference.setOption( "gl_renderer", CustomGLRenderer.class.getName() );

        Conference.Options audio_option =  conference.new Options();
        audio_option.setOption( "preferred-codec", "ISAC" );
        audio_option.setOption( "preferred-codec-clockrate", "16000" );
        conference.setOption( "audio", audio_option );

        init();
    }

    protected void init() {

        // Initialize loading spinner animation
        Animation rotation = AnimationUtils.loadAnimation(this, R.anim.rotate);
        if ( rotation != null )
            loader_spinner.startAnimation( rotation );


        // Force to use only Alphanumeric characters.
        InputFilter filter = new InputFilter() {
            public CharSequence filter(CharSequence source, int start, int end,
                                       Spanned dest, int dstart, int dend) {
                if ( !source.toString().matches("[a-zA-Z0-9_-]*") ) {
                    return "";
                }
                return null;
            }
        };
        room_name.setFilters(new InputFilter[]{filter});
        // Set keyboard action
        room_name.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                if (actionId == EditorInfo.IME_ACTION_SEND) {
                    join_button.performClick();
                    return true;
                }
                return false;
            }
        });

        // Set button listener
        join_button.setOnClickListener(this);
/*
        if ( conference.getCameraNb() == 0 ) {
            select_camera.setVisibility( View.GONE );
        } else {

            class CameraAdapter extends ArrayAdapter<CameraInfo> {
                public CameraAdapter(Context context, ArrayList<CameraInfo> infos) {
                    super(context, android.R.layout.simple_spinner_dropdown_item, infos);
                }

                @Override
                public View getView(int position, View convertView, ViewGroup parent) {
                    if(convertView == null)
                        convertView = View.inflate(getContext(),
                                android.R.layout.simple_spinner_dropdown_item,
                                null);

                    TextView tvText1 = (TextView)convertView.findViewById(android.R.id.text1);
                    CameraInfo info = getItem( position );
                    tvText1.setText( "Camera "  + position + " " + ( info.facing == CameraInfo.CAMERA_FACING_BACK ? "(back)" : "(front)" ) );

                    return convertView;
                }

                @Override
                public View getDropDownView(int position, View convertView, ViewGroup parent) {
                    return getView(position, convertView, parent);
                }
            }


            select_camera.setAdapter( new CameraAdapter ( this, conference.getCameraInfos() ) );
            select_camera.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> parentView, View selectedItemView, int position, long id) {
                    conference.setCameraId( position );
                }

                @Override
                public void onNothingSelected(AdapterView<?> adapterView) {}
            });
            select_camera.setSelection( conference.getCameraId() );
        }
*/
    }

    @Override
    protected void onResume()
    {
        super.onResume();

        conference = Conference.getInstance( getApplicationContext() );
        
        conference.addListener( this );

        Status state = conference.getStatus();

        if ( state == Status.DISCONNECTED ){
            conference.connect();
        }

        updateViewAccordingState(state);
    }

    @Override
    protected void onPause()
    {
        Log.d(TAG, "onPause");

        conference.removeListener( this );

        super.onPause();
    }

    @Override
    protected void onDestroy()
    {
        Log.d(TAG, "onDestroy");

        conference.disconnect();
        super.onDestroy();
    }

    private void updateViewAccordingState(Status state) {

        if ( state == Status.DISCONNECTED ) {
            status.setText( R.string.disconnected );
        } else if ( ( state == Status.CONNECTING ) || ( state == Status.CONNECTING_SENDREQUEST ) ) {
            status.setText( R.string.connecting );
        } else if ( state == Status.CONNECTED ) {
            status.setText( R.string.connected );
        }

        int loaderVisibility = ( state == Status.CONNECTING ) || ( state == Status.CONNECTING_SENDREQUEST ) ? View.VISIBLE : View.GONE;
        if ( loader_spinner.getVisibility() != loaderVisibility ) {
            loader_spinner.setVisibility( loaderVisibility );
        }

        room_name.setEnabled( state == Status.CONNECTED );
        join_button.setEnabled(state == Status.CONNECTED);
    }

    private void showCallLayout( boolean show ){
        room_layout.setVisibility( show ? View.GONE : View.VISIBLE );
        call_layout.setVisibility( show ? View.VISIBLE : View.GONE );
        if ( show ) {
            hideKeyboard();
        } else {
            call_layout.removeAllViews();
        }
    }

    @Override
    public void onBackPressed() {
        Log.w(TAG, "onBackPressed");

        if ( conference.isInRoom() ) {
            conference.leave();
            return;
        }
        super.onBackPressed();
    }

    @Override
    public void onClick( View view )
    {
        Log.d(TAG, "onClick");

        switch( view.getId() ) {
            case R.id.join_button:

                String roomName = room_name.getText().toString();

                if ( roomName == null || roomName.length() == 0 ) {
                    Toast.makeText(this, R.string.create_input_error, Toast.LENGTH_SHORT).show();
                    return;
                }

                if ( conference.getStatus() == Status.CONNECTED ) {
                    conference.join( roomName );
                    showCallLayout( true );
                    return;
                } else {
                    Log.w( TAG, "Cannot join room : not connected");
                }
                break;
        }
    }

    /*
    *       Listener implementation
    */

    @Override
    public void onConnectionEvent(Status state) {
        updateViewAccordingState(state);
        // Auto reconnect
        if ( state == Status.DISCONNECTED ) {
            conference.connect();
        }
    }

    @Override
    public void onError(ErrorEvent error) {
        if ( error == ErrorEvent.CONNECTION_ERROR ) {
            Toast.makeText(getApplicationContext(), "Connection error", Toast.LENGTH_LONG).show();
        }
    }

    @Override
    public void onRoomJoined(String room_name) {
        showCallLayout( true );
    }

    @Override
    public void onRoomQuited() {
        showCallLayout( false );
    }

    @Override
    public void onNewPeer( PeerStream peerStream ) {
        peerStream.setHandler( this );
    }

    @Override
    public void onVideoRatioChange(String peerId, MediaStream mediaStream, float ratio) {
        resizeAllVideo();
    }

    @Override
    public void onRemovedPeer(PeerStream peerStream) {
        if ( !peerStream.hasMedia() )
            return;

        MediaStream mediaStream = peerStream.getMedia();
        call_layout.removeView( mediaStream.getRender() );

        resizeAllVideo();
    }

    @Override
    public void onMediaStream(String peerId, MediaStream mediaStream) {

        mediaStream.setHandler( this );
        call_layout.addView( mediaStream.getRender() );
        resizeAllVideo();
    }

    public void resizeAllVideo() {
        // TODO this example need to be more simple

        String[]ids = conference.getPeerStream_Ids();

        int width = call_layout.getWidth();
        int height = call_layout.getHeight();

        int cpt = 0, nbView = 0;

        // Count video media
        for ( String id : ids ) {
            PeerStream peerStream = conference.getPeerStream( id );
            if ( peerStream.hasMedia() && peerStream.getMedia().hasVideo() )
                nbView++;
        }

        if ( nbView == 0 )
            return;

        int nbLine = (int) Math.ceil( (double)nbView / 2 );
        int nbCol = nbView > 2 ? 2 : nbView;

        int maxViewWidth = width / nbCol;
        int maxViewHeight = height / nbLine;

        for ( String id : ids ) {
            PeerStream peerStream = conference.getPeerStream( id );
            if ( !peerStream.hasMedia() || !peerStream.getMedia().hasVideo() ) {
                continue;
            }

            MediaStream media = peerStream.getMedia();
            float ratio = media.getVideoRatio();
            SurfaceView view = media.getRender();

            RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams( RelativeLayout.LayoutParams.WRAP_CONTENT, RelativeLayout.LayoutParams.WRAP_CONTENT );
            int viewWidth = maxViewWidth;
            int viewHeight = (int)( maxViewWidth / ratio );
            if ( viewHeight > maxViewHeight ) {
                viewHeight = maxViewHeight;
                viewWidth = (int)( maxViewHeight * ratio );
            }
            int vertMargin = ( viewHeight < maxViewHeight ) ? (maxViewHeight - viewHeight) / 2: 0;
            int horiMargin = ( viewWidth < maxViewWidth ) ? (maxViewWidth - viewWidth) / 2: 0;
            int left, right, top, bottom;
            left = right = top = bottom = 0;

            params.width = viewWidth;
            params.height = viewHeight;


            if ( cpt < 2 ) {
                // First line
                params.addRule(RelativeLayout.ALIGN_PARENT_TOP);
                top = vertMargin;
            } else {
                // Second line
                params.addRule(RelativeLayout.ALIGN_PARENT_BOTTOM);
                right = horiMargin;
            }
            if ( ( cpt % 2 ) == 0 ) {
                // First column
                params.addRule(RelativeLayout.ALIGN_PARENT_LEFT);
                left = horiMargin;
            } else {
                // Second column
                params.addRule(RelativeLayout.ALIGN_PARENT_RIGHT);
                right = horiMargin;
            }

            if ( cpt == 2 && nbView == 3 ) {
                left += maxViewWidth / 2;
            }
            params.setMargins( left, top, right, bottom );
            view.setLayoutParams( params );
            cpt++;
        }
    }

    public void hideKeyboard(){
        InputMethodManager imm = (InputMethodManager)getSystemService(
                Context.INPUT_METHOD_SERVICE);
        imm.hideSoftInputFromWindow(room_name.getWindowToken(), 0);
    }

}
