package com.bistri.api_demo;


import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.text.InputFilter;
import android.text.Spanned;
import android.view.inputmethod.InputMethodManager;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.Toast;
import android.util.Log;
import android.view.*;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.bistri.api.Conference;
import com.bistri.api.Conference.Status;
import com.bistri.api.Conference.ErrorEvent;
import com.bistri.api.MediaStream;
import com.bistri.api.PeerStream;
import com.googlecode.androidannotations.annotations.AfterViews;
import com.googlecode.androidannotations.annotations.EActivity;
import com.googlecode.androidannotations.annotations.ViewById;

@EActivity(R.layout.demo)
public class MainActivity extends Activity
    implements View.OnClickListener, Conference.Listener, PeerStream.Handler, MediaStream.Handler {
    // Static Fields
    private static final String TAG = "MainActivity";

    // Members
    @ViewById
    EditText room_name;

    @ViewById
    Button join_button;

    @ViewById
    TextView status;

    @ViewById
    ImageView loader_spinner;

    @ViewById
    RelativeLayout call_layout;

    @ViewById
    LinearLayout room_layout;

    private Conference conference;

    /*
    *       Activity Management
    */

    @AfterViews
    public void afterViews()
    {
        Log.d(TAG, "afterViews");

        // Initialize loading spinner animation
        Animation rotation = AnimationUtils.loadAnimation(this, R.anim.rotate);
        if ( rotation != null )
            loader_spinner.startAnimation( rotation );


        // Force to use only Alphanumeric characters.
        InputFilter filter = new InputFilter() {
            public CharSequence filter(CharSequence source, int start, int end,
                                       Spanned dest, int dstart, int dend) {
                if ( !source.toString().matches("[a-zA-Z0-9_-]*") ) {
                    return "";
                }
                return null;
            }
        };
        room_name.setFilters(new InputFilter[]{filter});
        // Set keyboard action
        room_name.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                if (actionId == EditorInfo.IME_ACTION_SEND) {
                    join_button.performClick();
                    return true;
                }
                return false;
            }
        });

        // Set button listener
        join_button.setOnClickListener(this);
    }

    @Override
    protected void onCreate (Bundle savedInstanceState)
    {
        super.onCreate( savedInstanceState );
        conference = Conference.getInstance( getApplicationContext() );
        conference.setInfo( "38077edb", "4f304359baa6d0fd1f9106aaeb116f33" );
        conference.setOption( "gl_renderer", CustomGLRenderer.class.getName() );
    }

    @Override
    protected void onResume()
    {
        super.onResume();

        conference = Conference.getInstance( getApplicationContext() );
        
        conference.addListener( this );

        Status state = conference.getState();

        if ( state == Status.DISCONNECTED ){
            conference.connect();
        }

        updateViewAccordingState(state);

    }

    @Override
    protected void onPause()
    {
        Log.d(TAG, "onPause");

        conference.removeListener( this );

        super.onPause();
    }

    @Override
    protected void onDestroy()
    {
        Log.d(TAG, "onDestroy");

        conference.disconnect();
        super.onDestroy();
    }

    private void updateViewAccordingState(Status state) {

        if ( state == Status.DISCONNECTED ) {
            status.setText( R.string.disconnected );
        } else if ( ( state == Status.CONNECTING ) || ( state == Status.CONNECTING_SENDREQUEST ) ) {
            status.setText( R.string.connecting );
        } else if ( state == Status.CONNECTED ) {
            status.setText( R.string.connected );
        }

        int loaderVisibility = ( state == Status.CONNECTING ) || ( state == Status.CONNECTING_SENDREQUEST ) ? View.VISIBLE : View.GONE;
        if ( loader_spinner.getVisibility() != loaderVisibility ) {
            loader_spinner.setVisibility( loaderVisibility );
        }

        room_name.setEnabled( state == Status.CONNECTED );
        join_button.setEnabled(state == Status.CONNECTED);
    }

    private void showCallLayout( boolean show ){
        room_layout.setVisibility( show ? View.GONE : View.VISIBLE );
        call_layout.setVisibility( show ? View.VISIBLE : View.GONE );
        if ( show ) {
            hideKeyboard();
        } else {
            call_layout.removeAllViews();
        }
    }

    @Override
    public void onBackPressed() {
        Log.w(TAG, "onBackPressed");

        if ( conference.isInRoom() ) {
            conference.leave();
            return;
        }
        super.onBackPressed();
    }

    @Override
    public void onClick( View view )
    {
        Log.d(TAG, "onClick");

        switch( view.getId() ) {
            case R.id.join_button:

                String roomName = room_name.getText().toString();

                if ( roomName == null || roomName.length() == 0 ) {
                    Toast.makeText(this, R.string.create_input_error, Toast.LENGTH_SHORT).show();
                    return;
                }

                Log.w( TAG, "Status : " + conference.getState() );
                if ( conference.getState() == Status.CONNECTED ) {
                    conference.join( roomName );
                    showCallLayout( true );
                    return;
                } else {
                    Log.w( TAG, "Cannot join room : not connected");
                }
                break;
        }
    }

    /*
    *       Listener implementation
    */

    @Override
    public void onConnectionEvent(Status state) {
        updateViewAccordingState(state);
        // Auto reconnect
        if ( state == Status.DISCONNECTED ) {
            conference.connect();
        }
    }

    @Override
    public void onError(ErrorEvent error) {
        if ( error == ErrorEvent.CONNECTION_ERROR ) {
            Toast.makeText(getApplicationContext(), "Connection error", Toast.LENGTH_LONG).show();
        }
    }

    @Override
    public void onRoomJoined(String room_name) {
        showCallLayout( true );
    }

    @Override
    public void onRoomQuited() {
        showCallLayout( false );
    }

    @Override
    public void onNewPeer( PeerStream peerStream ) {
        peerStream.setHandler( this );
    }

    @Override
    public void onVideoRatioChange(String peerId, MediaStream mediaStream, float ratio) {
        resizeAllVideo();
    }

    @Override
    public void onRemovedPeer(PeerStream peerStream) {
        if ( !peerStream.hasMedia() )
            return;

        MediaStream mediaStream = peerStream.getMedia();
        call_layout.removeView( mediaStream.getRender() );

        resizeAllVideo();
    }

    @Override
    public void onMediaStream(String peerId, MediaStream mediaStream) {

        mediaStream.setHandler( this );
        call_layout.addView( mediaStream.getRender() );
        resizeAllVideo();
    }

    public void resizeAllVideo() {
        // TODO this example need to be more simple

        String[]ids = conference.getPeerStream_Ids();

        int width = call_layout.getWidth();
        int height = call_layout.getHeight();

        int cpt = 0, nbView = 0;

        // Count video media
        for ( String id : ids ) {
            PeerStream peerStream = conference.GetPeerStream( id );
            if ( peerStream.hasMedia() && peerStream.getMedia().hasVideo() )
                nbView++;
        }

        if ( nbView == 0 )
            return;

        int nbLine = (int) Math.ceil( (double)nbView / 2 );
        int nbCol = nbView > 2 ? 2 : nbView;

        int maxViewWidth = width / nbCol;
        int maxViewHeight = height / nbLine;

        for ( String id : ids ) {
            PeerStream peerStream = conference.GetPeerStream( id );
            if ( !peerStream.hasMedia() || !peerStream.getMedia().hasVideo() ) {
                continue;
            }

            MediaStream media = peerStream.getMedia();
            float ratio = media.getVideoRatio();
            SurfaceView view = media.getRender();

            RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams( RelativeLayout.LayoutParams.WRAP_CONTENT, RelativeLayout.LayoutParams.WRAP_CONTENT );
            int viewWidth = maxViewWidth;
            int viewHeight = (int)( maxViewWidth / ratio );
            if ( viewHeight > maxViewHeight ) {
                viewHeight = maxViewHeight;
                viewWidth = (int)( maxViewHeight * ratio );
            }
            int vertMargin = ( viewHeight < maxViewHeight ) ? (maxViewHeight - viewHeight) / 2: 0;
            int horiMargin = ( viewWidth < maxViewWidth ) ? (maxViewWidth - viewWidth) / 2: 0;
            int left, right, top, bottom;
            left = right = top = bottom = 0;

            params.width = viewWidth;
            params.height = viewHeight;


            if ( cpt < 2 ) {
                // First line
                params.addRule(RelativeLayout.ALIGN_PARENT_TOP);
                top = vertMargin;
            } else {
                // Second line
                params.addRule(RelativeLayout.ALIGN_PARENT_BOTTOM);
                right = horiMargin;
            }
            if ( ( cpt % 2 ) == 0 ) {
                // First column
                params.addRule(RelativeLayout.ALIGN_PARENT_LEFT);
                left = horiMargin;
            } else {
                // Second column
                params.addRule(RelativeLayout.ALIGN_PARENT_RIGHT);
                right = horiMargin;
            }

            if ( cpt == 2 && nbView == 3 ) {
                left += maxViewWidth / 2;
            }
            params.setMargins( left, top, right, bottom );
            view.setLayoutParams( params );
            cpt++;
        }
    }

    public void hideKeyboard(){
        InputMethodManager imm = (InputMethodManager)getSystemService(
                Context.INPUT_METHOD_SERVICE);
        imm.hideSoftInputFromWindow(room_name.getWindowToken(), 0);
    }

}
